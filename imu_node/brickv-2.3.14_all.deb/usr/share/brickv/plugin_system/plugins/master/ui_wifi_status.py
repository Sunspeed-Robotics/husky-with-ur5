# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/wifi_status.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_WifiStatus(object):
    def setupUi(self, WifiStatus):
        WifiStatus.setObjectName(_fromUtf8("WifiStatus"))
        WifiStatus.resize(323, 286)
        self.verticalLayout = QtGui.QVBoxLayout(WifiStatus)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_8 = QtGui.QLabel(WifiStatus)
        self.label_8.setObjectName(_fromUtf8("label_8"))
        self.gridLayout.addWidget(self.label_8, 0, 0, 1, 1)
        self.label = QtGui.QLabel(WifiStatus)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)
        self.label_2 = QtGui.QLabel(WifiStatus)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 2, 0, 1, 1)
        self.label_3 = QtGui.QLabel(WifiStatus)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 3, 0, 1, 1)
        self.label_4 = QtGui.QLabel(WifiStatus)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 4, 0, 1, 1)
        self.label_5 = QtGui.QLabel(WifiStatus)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridLayout.addWidget(self.label_5, 5, 0, 1, 1)
        self.label_6 = QtGui.QLabel(WifiStatus)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.gridLayout.addWidget(self.label_6, 6, 0, 1, 1)
        self.label_7 = QtGui.QLabel(WifiStatus)
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.gridLayout.addWidget(self.label_7, 7, 0, 1, 1)
        self.label_9 = QtGui.QLabel(WifiStatus)
        self.label_9.setObjectName(_fromUtf8("label_9"))
        self.gridLayout.addWidget(self.label_9, 8, 0, 1, 1)
        self.label_10 = QtGui.QLabel(WifiStatus)
        self.label_10.setObjectName(_fromUtf8("label_10"))
        self.gridLayout.addWidget(self.label_10, 9, 0, 1, 1)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 0, 1, 1, 1)
        self.wifi_status_ip = QtGui.QLabel(WifiStatus)
        self.wifi_status_ip.setText(_fromUtf8(""))
        self.wifi_status_ip.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.wifi_status_ip.setObjectName(_fromUtf8("wifi_status_ip"))
        self.gridLayout.addWidget(self.wifi_status_ip, 2, 2, 1, 1)
        self.wifi_status_state = QtGui.QLabel(WifiStatus)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.wifi_status_state.sizePolicy().hasHeightForWidth())
        self.wifi_status_state.setSizePolicy(sizePolicy)
        self.wifi_status_state.setText(_fromUtf8(""))
        self.wifi_status_state.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.wifi_status_state.setObjectName(_fromUtf8("wifi_status_state"))
        self.gridLayout.addWidget(self.wifi_status_state, 0, 2, 1, 1)
        self.wifi_status_rssi = QtGui.QLabel(WifiStatus)
        self.wifi_status_rssi.setText(_fromUtf8(""))
        self.wifi_status_rssi.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.wifi_status_rssi.setObjectName(_fromUtf8("wifi_status_rssi"))
        self.gridLayout.addWidget(self.wifi_status_rssi, 1, 2, 1, 1)
        self.wifi_status_sub = QtGui.QLabel(WifiStatus)
        self.wifi_status_sub.setText(_fromUtf8(""))
        self.wifi_status_sub.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.wifi_status_sub.setObjectName(_fromUtf8("wifi_status_sub"))
        self.gridLayout.addWidget(self.wifi_status_sub, 3, 2, 1, 1)
        self.wifi_status_gw = QtGui.QLabel(WifiStatus)
        self.wifi_status_gw.setText(_fromUtf8(""))
        self.wifi_status_gw.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.wifi_status_gw.setObjectName(_fromUtf8("wifi_status_gw"))
        self.gridLayout.addWidget(self.wifi_status_gw, 4, 2, 1, 1)
        self.wifi_status_channel = QtGui.QLabel(WifiStatus)
        self.wifi_status_channel.setText(_fromUtf8(""))
        self.wifi_status_channel.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.wifi_status_channel.setObjectName(_fromUtf8("wifi_status_channel"))
        self.gridLayout.addWidget(self.wifi_status_channel, 5, 2, 1, 1)
        self.wifi_status_mac = QtGui.QLabel(WifiStatus)
        self.wifi_status_mac.setText(_fromUtf8(""))
        self.wifi_status_mac.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.wifi_status_mac.setObjectName(_fromUtf8("wifi_status_mac"))
        self.gridLayout.addWidget(self.wifi_status_mac, 6, 2, 1, 1)
        self.wifi_status_bssid = QtGui.QLabel(WifiStatus)
        self.wifi_status_bssid.setText(_fromUtf8(""))
        self.wifi_status_bssid.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.wifi_status_bssid.setObjectName(_fromUtf8("wifi_status_bssid"))
        self.gridLayout.addWidget(self.wifi_status_bssid, 7, 2, 1, 1)
        self.wifi_status_rx = QtGui.QLabel(WifiStatus)
        self.wifi_status_rx.setText(_fromUtf8(""))
        self.wifi_status_rx.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.wifi_status_rx.setObjectName(_fromUtf8("wifi_status_rx"))
        self.gridLayout.addWidget(self.wifi_status_rx, 8, 2, 1, 1)
        self.wifi_status_tx = QtGui.QLabel(WifiStatus)
        self.wifi_status_tx.setText(_fromUtf8(""))
        self.wifi_status_tx.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.wifi_status_tx.setObjectName(_fromUtf8("wifi_status_tx"))
        self.gridLayout.addWidget(self.wifi_status_tx, 9, 2, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        spacerItem1 = QtGui.QSpacerItem(20, 6, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem1)
        self.button_close = QtGui.QPushButton(WifiStatus)
        self.button_close.setObjectName(_fromUtf8("button_close"))
        self.verticalLayout.addWidget(self.button_close)

        self.retranslateUi(WifiStatus)
        QtCore.QMetaObject.connectSlotsByName(WifiStatus)

    def retranslateUi(self, WifiStatus):
        WifiStatus.setWindowTitle(_translate("WifiStatus", "WIFI Status", None))
        self.label_8.setText(_translate("WifiStatus", "State:", None))
        self.label.setText(_translate("WifiStatus", "Signal Strength:", None))
        self.label_2.setText(_translate("WifiStatus", "IP:", None))
        self.label_3.setText(_translate("WifiStatus", "Subnet Mask:", None))
        self.label_4.setText(_translate("WifiStatus", "Gateway:", None))
        self.label_5.setText(_translate("WifiStatus", "Channel:", None))
        self.label_6.setText(_translate("WifiStatus", "MAC Address:", None))
        self.label_7.setText(_translate("WifiStatus", "BSSID:", None))
        self.label_9.setText(_translate("WifiStatus", "RX Count:", None))
        self.label_10.setText(_translate("WifiStatus", "TX Count:", None))
        self.button_close.setText(_translate("WifiStatus", "Close", None))

