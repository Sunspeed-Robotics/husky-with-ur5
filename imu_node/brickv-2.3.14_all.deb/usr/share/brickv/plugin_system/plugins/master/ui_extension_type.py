# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/extension_type.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ExtensionType(object):
    def setupUi(self, ExtensionType):
        ExtensionType.setObjectName(_fromUtf8("ExtensionType"))
        ExtensionType.resize(280, 78)
        self.gridLayout = QtGui.QGridLayout(ExtensionType)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_2 = QtGui.QLabel(ExtensionType)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 0, 0, 1, 1)
        self.combo_extension = QtGui.QComboBox(ExtensionType)
        self.combo_extension.setObjectName(_fromUtf8("combo_extension"))
        self.combo_extension.addItem(_fromUtf8(""))
        self.combo_extension.addItem(_fromUtf8(""))
        self.gridLayout.addWidget(self.combo_extension, 0, 1, 1, 2)
        self.label_9 = QtGui.QLabel(ExtensionType)
        self.label_9.setObjectName(_fromUtf8("label_9"))
        self.gridLayout.addWidget(self.label_9, 1, 0, 1, 1)
        self.type_box = QtGui.QComboBox(ExtensionType)
        self.type_box.setObjectName(_fromUtf8("type_box"))
        self.type_box.addItem(_fromUtf8(""))
        self.type_box.addItem(_fromUtf8(""))
        self.type_box.addItem(_fromUtf8(""))
        self.type_box.addItem(_fromUtf8(""))
        self.type_box.addItem(_fromUtf8(""))
        self.type_box.addItem(_fromUtf8(""))
        self.gridLayout.addWidget(self.type_box, 1, 1, 1, 1)
        self.button_type_save = QtGui.QPushButton(ExtensionType)
        self.button_type_save.setObjectName(_fromUtf8("button_type_save"))
        self.gridLayout.addWidget(self.button_type_save, 1, 2, 1, 1)

        self.retranslateUi(ExtensionType)
        QtCore.QMetaObject.connectSlotsByName(ExtensionType)

    def retranslateUi(self, ExtensionType):
        ExtensionType.setWindowTitle(_translate("ExtensionType", "Configure Extension Type", None))
        self.label_2.setText(_translate("ExtensionType", "Extension:", None))
        self.combo_extension.setItemText(0, _translate("ExtensionType", "0", None))
        self.combo_extension.setItemText(1, _translate("ExtensionType", "1", None))
        self.label_9.setText(_translate("ExtensionType", "Type:", None))
        self.type_box.setItemText(0, _translate("ExtensionType", "None", None))
        self.type_box.setItemText(1, _translate("ExtensionType", "Chibi", None))
        self.type_box.setItemText(2, _translate("ExtensionType", "RS485", None))
        self.type_box.setItemText(3, _translate("ExtensionType", "WIFI", None))
        self.type_box.setItemText(4, _translate("ExtensionType", "Ethernet", None))
        self.type_box.setItemText(5, _translate("ExtensionType", "WIFI 2.0", None))
        self.button_type_save.setText(_translate("ExtensionType", "Save", None))

