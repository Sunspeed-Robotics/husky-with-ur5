# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/industrial_analog_out.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_IndustrialAnalogOut(object):
    def setupUi(self, IndustrialAnalogOut):
        IndustrialAnalogOut.setObjectName(_fromUtf8("IndustrialAnalogOut"))
        IndustrialAnalogOut.resize(673, 177)
        self.verticalLayout = QtGui.QVBoxLayout(IndustrialAnalogOut)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)
        self.checkbox_enable = QtGui.QCheckBox(IndustrialAnalogOut)
        self.checkbox_enable.setObjectName(_fromUtf8("checkbox_enable"))
        self.horizontalLayout_2.addWidget(self.checkbox_enable)
        self.radio_voltage = QtGui.QRadioButton(IndustrialAnalogOut)
        self.radio_voltage.setChecked(True)
        self.radio_voltage.setObjectName(_fromUtf8("radio_voltage"))
        self.horizontalLayout_2.addWidget(self.radio_voltage)
        self.radio_current = QtGui.QRadioButton(IndustrialAnalogOut)
        self.radio_current.setObjectName(_fromUtf8("radio_current"))
        self.horizontalLayout_2.addWidget(self.radio_current)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem1)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.line = QtGui.QFrame(IndustrialAnalogOut)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.verticalLayout.addWidget(self.line)
        self.widget_voltage = QtGui.QWidget(IndustrialAnalogOut)
        self.widget_voltage.setObjectName(_fromUtf8("widget_voltage"))
        self.horizontalLayout_3 = QtGui.QHBoxLayout(self.widget_voltage)
        self.horizontalLayout_3.setMargin(0)
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.label_voltage = QtGui.QLabel(self.widget_voltage)
        self.label_voltage.setObjectName(_fromUtf8("label_voltage"))
        self.horizontalLayout_3.addWidget(self.label_voltage)
        self.slider_voltage = QtGui.QSlider(self.widget_voltage)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.slider_voltage.sizePolicy().hasHeightForWidth())
        self.slider_voltage.setSizePolicy(sizePolicy)
        self.slider_voltage.setMaximum(10000)
        self.slider_voltage.setPageStep(1000)
        self.slider_voltage.setOrientation(QtCore.Qt.Horizontal)
        self.slider_voltage.setObjectName(_fromUtf8("slider_voltage"))
        self.horizontalLayout_3.addWidget(self.slider_voltage)
        self.spin_voltage = QtGui.QSpinBox(self.widget_voltage)
        self.spin_voltage.setMaximum(10000)
        self.spin_voltage.setSingleStep(100)
        self.spin_voltage.setObjectName(_fromUtf8("spin_voltage"))
        self.horizontalLayout_3.addWidget(self.spin_voltage)
        self.label_voltage_range = QtGui.QLabel(self.widget_voltage)
        self.label_voltage_range.setObjectName(_fromUtf8("label_voltage_range"))
        self.horizontalLayout_3.addWidget(self.label_voltage_range)
        self.box_voltage_range = QtGui.QComboBox(self.widget_voltage)
        self.box_voltage_range.setObjectName(_fromUtf8("box_voltage_range"))
        self.box_voltage_range.addItem(_fromUtf8(""))
        self.box_voltage_range.addItem(_fromUtf8(""))
        self.horizontalLayout_3.addWidget(self.box_voltage_range)
        self.verticalLayout.addWidget(self.widget_voltage)
        self.widget_current = QtGui.QWidget(IndustrialAnalogOut)
        self.widget_current.setObjectName(_fromUtf8("widget_current"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.widget_current)
        self.horizontalLayout.setMargin(0)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.label_current = QtGui.QLabel(self.widget_current)
        self.label_current.setObjectName(_fromUtf8("label_current"))
        self.horizontalLayout.addWidget(self.label_current)
        self.slider_current = QtGui.QSlider(self.widget_current)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.slider_current.sizePolicy().hasHeightForWidth())
        self.slider_current.setSizePolicy(sizePolicy)
        self.slider_current.setMinimum(4000)
        self.slider_current.setMaximum(20000)
        self.slider_current.setPageStep(1000)
        self.slider_current.setOrientation(QtCore.Qt.Horizontal)
        self.slider_current.setObjectName(_fromUtf8("slider_current"))
        self.horizontalLayout.addWidget(self.slider_current)
        self.spin_current = QtGui.QSpinBox(self.widget_current)
        self.spin_current.setMinimum(4000)
        self.spin_current.setMaximum(20000)
        self.spin_current.setSingleStep(100)
        self.spin_current.setObjectName(_fromUtf8("spin_current"))
        self.horizontalLayout.addWidget(self.spin_current)
        self.label_current_range = QtGui.QLabel(self.widget_current)
        self.label_current_range.setObjectName(_fromUtf8("label_current_range"))
        self.horizontalLayout.addWidget(self.label_current_range)
        self.box_current_range = QtGui.QComboBox(self.widget_current)
        self.box_current_range.setObjectName(_fromUtf8("box_current_range"))
        self.box_current_range.addItem(_fromUtf8(""))
        self.box_current_range.addItem(_fromUtf8(""))
        self.box_current_range.addItem(_fromUtf8(""))
        self.horizontalLayout.addWidget(self.box_current_range)
        self.verticalLayout.addWidget(self.widget_current)
        spacerItem2 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem2)

        self.retranslateUi(IndustrialAnalogOut)
        QtCore.QMetaObject.connectSlotsByName(IndustrialAnalogOut)

    def retranslateUi(self, IndustrialAnalogOut):
        IndustrialAnalogOut.setWindowTitle(_translate("IndustrialAnalogOut", "Form", None))
        self.checkbox_enable.setText(_translate("IndustrialAnalogOut", "Enable Output", None))
        self.radio_voltage.setText(_translate("IndustrialAnalogOut", "Voltage", None))
        self.radio_current.setText(_translate("IndustrialAnalogOut", "Current", None))
        self.label_voltage.setText(_translate("IndustrialAnalogOut", "Output Voltage [mV]:", None))
        self.label_voltage_range.setText(_translate("IndustrialAnalogOut", "Range:", None))
        self.box_voltage_range.setItemText(0, _translate("IndustrialAnalogOut", "0 - 5 V", None))
        self.box_voltage_range.setItemText(1, _translate("IndustrialAnalogOut", "0 - 10 V", None))
        self.label_current.setText(_translate("IndustrialAnalogOut", "Output Current [µA]:", None))
        self.label_current_range.setText(_translate("IndustrialAnalogOut", "Range:", None))
        self.box_current_range.setItemText(0, _translate("IndustrialAnalogOut", "4 - 20 mA", None))
        self.box_current_range.setItemText(1, _translate("IndustrialAnalogOut", "0 - 20 mA", None))
        self.box_current_range.setItemText(2, _translate("IndustrialAnalogOut", "0 - 24 mA", None))

