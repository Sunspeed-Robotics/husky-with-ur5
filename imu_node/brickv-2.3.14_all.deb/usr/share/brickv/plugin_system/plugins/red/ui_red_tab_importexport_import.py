# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_importexport_import.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabImportExportImport(object):
    def setupUi(self, REDTabImportExportImport):
        REDTabImportExportImport.setObjectName(_fromUtf8("REDTabImportExportImport"))
        REDTabImportExportImport.resize(627, 406)
        self.verticalLayout = QtGui.QVBoxLayout(REDTabImportExportImport)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(REDTabImportExportImport)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.label_2 = QtGui.QLabel(REDTabImportExportImport)
        self.label_2.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.edit_archive = QtGui.QLineEdit(REDTabImportExportImport)
        self.edit_archive.setObjectName(_fromUtf8("edit_archive"))
        self.horizontalLayout.addWidget(self.edit_archive)
        self.button_browse_archive = QtGui.QPushButton(REDTabImportExportImport)
        self.button_browse_archive.setObjectName(_fromUtf8("button_browse_archive"))
        self.horizontalLayout.addWidget(self.button_browse_archive)
        self.gridLayout.addLayout(self.horizontalLayout, 0, 1, 1, 1)
        self.button_refresh_programs = QtGui.QPushButton(REDTabImportExportImport)
        self.button_refresh_programs.setObjectName(_fromUtf8("button_refresh_programs"))
        self.gridLayout.addWidget(self.button_refresh_programs, 3, 1, 1, 1)
        self.button_import = QtGui.QPushButton(REDTabImportExportImport)
        self.button_import.setObjectName(_fromUtf8("button_import"))
        self.gridLayout.addWidget(self.button_import, 5, 1, 1, 1)
        self.line = QtGui.QFrame(REDTabImportExportImport)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout.addWidget(self.line, 4, 0, 1, 2)
        self.progress_refresh_programs = QtGui.QProgressBar(REDTabImportExportImport)
        self.progress_refresh_programs.setMaximum(0)
        self.progress_refresh_programs.setProperty("value", -1)
        self.progress_refresh_programs.setTextVisible(False)
        self.progress_refresh_programs.setObjectName(_fromUtf8("progress_refresh_programs"))
        self.gridLayout.addWidget(self.progress_refresh_programs, 2, 1, 1, 1)
        self.tree_programs = QtGui.QTreeWidget(REDTabImportExportImport)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.tree_programs.sizePolicy().hasHeightForWidth())
        self.tree_programs.setSizePolicy(sizePolicy)
        self.tree_programs.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.tree_programs.setSelectionMode(QtGui.QAbstractItemView.ExtendedSelection)
        self.tree_programs.setRootIsDecorated(False)
        self.tree_programs.setObjectName(_fromUtf8("tree_programs"))
        self.gridLayout.addWidget(self.tree_programs, 1, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.label.setBuddy(self.edit_archive)

        self.retranslateUi(REDTabImportExportImport)
        QtCore.QMetaObject.connectSlotsByName(REDTabImportExportImport)
        REDTabImportExportImport.setTabOrder(self.edit_archive, self.button_browse_archive)
        REDTabImportExportImport.setTabOrder(self.button_browse_archive, self.tree_programs)
        REDTabImportExportImport.setTabOrder(self.tree_programs, self.button_refresh_programs)
        REDTabImportExportImport.setTabOrder(self.button_refresh_programs, self.button_import)

    def retranslateUi(self, REDTabImportExportImport):
        REDTabImportExportImport.setWindowTitle(_translate("REDTabImportExportImport", "Form", None))
        self.label.setText(_translate("REDTabImportExportImport", "Archive:", None))
        self.label_2.setText(_translate("REDTabImportExportImport", "Programs:", None))
        self.button_browse_archive.setText(_translate("REDTabImportExportImport", "Browse", None))
        self.button_refresh_programs.setText(_translate("REDTabImportExportImport", "Refresh", None))
        self.button_import.setText(_translate("REDTabImportExportImport", "Import and Reboot", None))
        self.tree_programs.headerItem().setText(0, _translate("REDTabImportExportImport", "Name", None))
        self.tree_programs.headerItem().setText(1, _translate("REDTabImportExportImport", "Identifier", None))
        self.tree_programs.headerItem().setText(2, _translate("REDTabImportExportImport", "Language", None))
        self.tree_programs.headerItem().setText(3, _translate("REDTabImportExportImport", "Status", None))

