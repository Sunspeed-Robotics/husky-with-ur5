# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_info_java.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramInfoJava(object):
    def setupUi(self, ProgramInfoJava):
        ProgramInfoJava.setObjectName(_fromUtf8("ProgramInfoJava"))
        ProgramInfoJava.resize(535, 231)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramInfoJava)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_version_title = QtGui.QLabel(ProgramInfoJava)
        self.label_version_title.setObjectName(_fromUtf8("label_version_title"))
        self.gridLayout.addWidget(self.label_version_title, 0, 0, 1, 1)
        self.label_2 = QtGui.QLabel(ProgramInfoJava)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.label_main_class_title = QtGui.QLabel(ProgramInfoJava)
        self.label_main_class_title.setObjectName(_fromUtf8("label_main_class_title"))
        self.gridLayout.addWidget(self.label_main_class_title, 2, 0, 1, 1)
        self.label_jar_file_title = QtGui.QLabel(ProgramInfoJava)
        self.label_jar_file_title.setObjectName(_fromUtf8("label_jar_file_title"))
        self.gridLayout.addWidget(self.label_jar_file_title, 3, 0, 1, 1)
        self.label_working_directory_title = QtGui.QLabel(ProgramInfoJava)
        self.label_working_directory_title.setObjectName(_fromUtf8("label_working_directory_title"))
        self.gridLayout.addWidget(self.label_working_directory_title, 9, 0, 1, 1)
        self.line = QtGui.QFrame(ProgramInfoJava)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout.addWidget(self.line, 7, 0, 1, 2)
        self.label_version = QtGui.QLabel(ProgramInfoJava)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_version.sizePolicy().hasHeightForWidth())
        self.label_version.setSizePolicy(sizePolicy)
        self.label_version.setTextFormat(QtCore.Qt.PlainText)
        self.label_version.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_version.setObjectName(_fromUtf8("label_version"))
        self.gridLayout.addWidget(self.label_version, 0, 1, 1, 1)
        self.label_start_mode = QtGui.QLabel(ProgramInfoJava)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_start_mode.sizePolicy().hasHeightForWidth())
        self.label_start_mode.setSizePolicy(sizePolicy)
        self.label_start_mode.setTextFormat(QtCore.Qt.PlainText)
        self.label_start_mode.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_start_mode.setObjectName(_fromUtf8("label_start_mode"))
        self.gridLayout.addWidget(self.label_start_mode, 1, 1, 1, 1)
        self.label_main_class = QtGui.QLabel(ProgramInfoJava)
        self.label_main_class.setTextFormat(QtCore.Qt.PlainText)
        self.label_main_class.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_main_class.setObjectName(_fromUtf8("label_main_class"))
        self.gridLayout.addWidget(self.label_main_class, 2, 1, 1, 1)
        self.label_jar_file = QtGui.QLabel(ProgramInfoJava)
        self.label_jar_file.setTextFormat(QtCore.Qt.PlainText)
        self.label_jar_file.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_jar_file.setObjectName(_fromUtf8("label_jar_file"))
        self.gridLayout.addWidget(self.label_jar_file, 3, 1, 1, 1)
        self.label_working_directory = QtGui.QLabel(ProgramInfoJava)
        self.label_working_directory.setTextFormat(QtCore.Qt.PlainText)
        self.label_working_directory.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_working_directory.setObjectName(_fromUtf8("label_working_directory"))
        self.gridLayout.addWidget(self.label_working_directory, 9, 1, 1, 1)
        self.check_show_advanced_options = QtGui.QCheckBox(ProgramInfoJava)
        self.check_show_advanced_options.setObjectName(_fromUtf8("check_show_advanced_options"))
        self.gridLayout.addWidget(self.check_show_advanced_options, 8, 1, 1, 1)
        self.label_options_title = QtGui.QLabel(ProgramInfoJava)
        self.label_options_title.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_options_title.setObjectName(_fromUtf8("label_options_title"))
        self.gridLayout.addWidget(self.label_options_title, 10, 0, 1, 1)
        self.label_options = QtGui.QLabel(ProgramInfoJava)
        self.label_options.setTextFormat(QtCore.Qt.PlainText)
        self.label_options.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_options.setObjectName(_fromUtf8("label_options"))
        self.gridLayout.addWidget(self.label_options, 10, 1, 1, 1)
        self.check_show_class_path = QtGui.QCheckBox(ProgramInfoJava)
        self.check_show_class_path.setObjectName(_fromUtf8("check_show_class_path"))
        self.gridLayout.addWidget(self.check_show_class_path, 5, 1, 1, 1)
        self.line_2 = QtGui.QFrame(ProgramInfoJava)
        self.line_2.setFrameShape(QtGui.QFrame.HLine)
        self.line_2.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_2.setObjectName(_fromUtf8("line_2"))
        self.gridLayout.addWidget(self.line_2, 4, 0, 1, 2)
        self.label_class_path_title = QtGui.QLabel(ProgramInfoJava)
        self.label_class_path_title.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_class_path_title.setObjectName(_fromUtf8("label_class_path_title"))
        self.gridLayout.addWidget(self.label_class_path_title, 6, 0, 1, 1)
        self.label_class_path = QtGui.QLabel(ProgramInfoJava)
        self.label_class_path.setTextFormat(QtCore.Qt.PlainText)
        self.label_class_path.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_class_path.setObjectName(_fromUtf8("label_class_path"))
        self.gridLayout.addWidget(self.label_class_path, 6, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)

        self.retranslateUi(ProgramInfoJava)
        QtCore.QMetaObject.connectSlotsByName(ProgramInfoJava)

    def retranslateUi(self, ProgramInfoJava):
        ProgramInfoJava.setWindowTitle(_translate("ProgramInfoJava", "Form", None))
        self.label_version_title.setText(_translate("ProgramInfoJava", "Java Version:", None))
        self.label_2.setText(_translate("ProgramInfoJava", "Start Mode:", None))
        self.label_main_class_title.setText(_translate("ProgramInfoJava", "Main Class:", None))
        self.label_jar_file_title.setText(_translate("ProgramInfoJava", "JAR File:", None))
        self.label_working_directory_title.setText(_translate("ProgramInfoJava", "Working Directory:", None))
        self.label_version.setText(_translate("ProgramInfoJava", "Fetching Versions...", None))
        self.label_start_mode.setText(_translate("ProgramInfoJava", "<start-mode>", None))
        self.label_main_class.setText(_translate("ProgramInfoJava", "<main-class>", None))
        self.label_jar_file.setText(_translate("ProgramInfoJava", "<jar-file>", None))
        self.label_working_directory.setText(_translate("ProgramInfoJava", "<working-directory>", None))
        self.check_show_advanced_options.setText(_translate("ProgramInfoJava", "Show Advanced Options", None))
        self.label_options_title.setText(_translate("ProgramInfoJava", "JVM Options:", None))
        self.label_options.setText(_translate("ProgramInfoJava", "<jvm-options>", None))
        self.check_show_class_path.setText(_translate("ProgramInfoJava", "Show Class Path", None))
        self.label_class_path_title.setText(_translate("ProgramInfoJava", "Class Path:", None))
        self.label_class_path.setText(_translate("ProgramInfoJava", "<class-path>", None))

