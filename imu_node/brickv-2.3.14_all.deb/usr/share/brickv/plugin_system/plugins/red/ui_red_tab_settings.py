# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_settings.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabSettings(object):
    def setupUi(self, REDTabSettings):
        REDTabSettings.setObjectName(_fromUtf8("REDTabSettings"))
        REDTabSettings.resize(742, 569)
        self.verticalLayout = QtGui.QVBoxLayout(REDTabSettings)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.label_discovering = QtGui.QLabel(REDTabSettings)
        self.label_discovering.setAlignment(QtCore.Qt.AlignCenter)
        self.label_discovering.setWordWrap(True)
        self.label_discovering.setObjectName(_fromUtf8("label_discovering"))
        self.verticalLayout.addWidget(self.label_discovering)
        self.tab_widget = QtGui.QTabWidget(REDTabSettings)
        self.tab_widget.setObjectName(_fromUtf8("tab_widget"))
        self.tab_network = REDTabSettingsNetwork()
        self.tab_network.setObjectName(_fromUtf8("tab_network"))
        self.tab_widget.addTab(self.tab_network, _fromUtf8(""))
        self.tab_ap = REDTabSettingsAP()
        self.tab_ap.setObjectName(_fromUtf8("tab_ap"))
        self.tab_widget.addTab(self.tab_ap, _fromUtf8(""))
        self.tab_mobile_internet = REDTabSettingsMobileInternet()
        self.tab_mobile_internet.setObjectName(_fromUtf8("tab_mobile_internet"))
        self.tab_widget.addTab(self.tab_mobile_internet, _fromUtf8(""))
        self.tab_server_monitoring = REDTabSettingsServerMonitoring()
        self.tab_server_monitoring.setObjectName(_fromUtf8("tab_server_monitoring"))
        self.tab_widget.addTab(self.tab_server_monitoring, _fromUtf8(""))
        self.tab_openhab = REDTabSettingsOpenHAB()
        self.tab_openhab.setObjectName(_fromUtf8("tab_openhab"))
        self.tab_widget.addTab(self.tab_openhab, _fromUtf8(""))
        self.tab_brickd = REDTabSettingsBrickd()
        self.tab_brickd.setObjectName(_fromUtf8("tab_brickd"))
        self.tab_widget.addTab(self.tab_brickd, _fromUtf8(""))
        self.tab_datetime = REDTabSettingsDateTime()
        self.tab_datetime.setObjectName(_fromUtf8("tab_datetime"))
        self.tab_widget.addTab(self.tab_datetime, _fromUtf8(""))
        self.tab_filesystem = REDTabSettingsFileSystem()
        self.tab_filesystem.setObjectName(_fromUtf8("tab_filesystem"))
        self.tab_widget.addTab(self.tab_filesystem, _fromUtf8(""))
        self.tab_services = REDTabSettingsServices()
        self.tab_services.setObjectName(_fromUtf8("tab_services"))
        self.tab_widget.addTab(self.tab_services, _fromUtf8(""))
        self.verticalLayout.addWidget(self.tab_widget)

        self.retranslateUi(REDTabSettings)
        self.tab_widget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(REDTabSettings)

    def retranslateUi(self, REDTabSettings):
        REDTabSettings.setWindowTitle(_translate("REDTabSettings", "REDTabSettings", None))
        self.label_discovering.setText(_translate("REDTabSettings", "Discovering Services...", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_network), _translate("REDTabSettings", "Network", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_ap), _translate("REDTabSettings", "Access Point", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_mobile_internet), _translate("REDTabSettings", "Mobile Internet", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_server_monitoring), _translate("REDTabSettings", "Server Monitoring", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_openhab), _translate("REDTabSettings", "openHAB", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_brickd), _translate("REDTabSettings", "Brick Daemon", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_datetime), _translate("REDTabSettings", "Date/Time", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_filesystem), _translate("REDTabSettings", "File System", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_services), _translate("REDTabSettings", "Services", None))

from brickv.plugin_system.plugins.red.red_tab_settings_ap import REDTabSettingsAP
from brickv.plugin_system.plugins.red.red_tab_settings_brickd import REDTabSettingsBrickd
from brickv.plugin_system.plugins.red.red_tab_settings_datetime import REDTabSettingsDateTime
from brickv.plugin_system.plugins.red.red_tab_settings_filesystem import REDTabSettingsFileSystem
from brickv.plugin_system.plugins.red.red_tab_settings_mobile_internet import REDTabSettingsMobileInternet
from brickv.plugin_system.plugins.red.red_tab_settings_network import REDTabSettingsNetwork
from brickv.plugin_system.plugins.red.red_tab_settings_openhab import REDTabSettingsOpenHAB
from brickv.plugin_system.plugins.red.red_tab_settings_server_monitoring import REDTabSettingsServerMonitoring
from brickv.plugin_system.plugins.red.red_tab_settings_services import REDTabSettingsServices
