# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_importexport_export.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabImportExportExport(object):
    def setupUi(self, REDTabImportExportExport):
        REDTabImportExportExport.setObjectName(_fromUtf8("REDTabImportExportExport"))
        REDTabImportExportExport.resize(837, 473)
        self.verticalLayout = QtGui.QVBoxLayout(REDTabImportExportExport)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout_2 = QtGui.QGridLayout()
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.label = QtGui.QLabel(REDTabImportExportExport)
        self.label.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 1)
        self.button_export = QtGui.QPushButton(REDTabImportExportExport)
        self.button_export.setObjectName(_fromUtf8("button_export"))
        self.gridLayout_2.addWidget(self.button_export, 4, 1, 1, 1)
        self.line = QtGui.QFrame(REDTabImportExportExport)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout_2.addWidget(self.line, 3, 0, 1, 2)
        self.button_refresh_programs = QtGui.QPushButton(REDTabImportExportExport)
        self.button_refresh_programs.setObjectName(_fromUtf8("button_refresh_programs"))
        self.gridLayout_2.addWidget(self.button_refresh_programs, 2, 1, 1, 1)
        self.progress_refresh_programs = QtGui.QProgressBar(REDTabImportExportExport)
        self.progress_refresh_programs.setMaximum(0)
        self.progress_refresh_programs.setProperty("value", 0)
        self.progress_refresh_programs.setTextVisible(False)
        self.progress_refresh_programs.setObjectName(_fromUtf8("progress_refresh_programs"))
        self.gridLayout_2.addWidget(self.progress_refresh_programs, 1, 1, 1, 1)
        self.tree_programs = QtGui.QTreeWidget(REDTabImportExportExport)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.tree_programs.sizePolicy().hasHeightForWidth())
        self.tree_programs.setSizePolicy(sizePolicy)
        self.tree_programs.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.tree_programs.setSelectionMode(QtGui.QAbstractItemView.ExtendedSelection)
        self.tree_programs.setRootIsDecorated(False)
        self.tree_programs.setObjectName(_fromUtf8("tree_programs"))
        self.gridLayout_2.addWidget(self.tree_programs, 0, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout_2)
        self.label.setBuddy(self.tree_programs)

        self.retranslateUi(REDTabImportExportExport)
        QtCore.QMetaObject.connectSlotsByName(REDTabImportExportExport)
        REDTabImportExportExport.setTabOrder(self.tree_programs, self.button_refresh_programs)
        REDTabImportExportExport.setTabOrder(self.button_refresh_programs, self.button_export)

    def retranslateUi(self, REDTabImportExportExport):
        REDTabImportExportExport.setWindowTitle(_translate("REDTabImportExportExport", "Form", None))
        self.label.setText(_translate("REDTabImportExportExport", "Programs:", None))
        self.button_export.setText(_translate("REDTabImportExportExport", "Export", None))
        self.button_refresh_programs.setText(_translate("REDTabImportExportExport", "Refresh", None))
        self.tree_programs.headerItem().setText(0, _translate("REDTabImportExportExport", "Name", None))
        self.tree_programs.headerItem().setText(1, _translate("REDTabImportExportExport", "Identifier", None))
        self.tree_programs.headerItem().setText(2, _translate("REDTabImportExportExport", "Language", None))

