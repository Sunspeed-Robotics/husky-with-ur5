# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_info_delphi_compile.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramInfoDelphiCompile(object):
    def setupUi(self, ProgramInfoDelphiCompile):
        ProgramInfoDelphiCompile.setObjectName(_fromUtf8("ProgramInfoDelphiCompile"))
        ProgramInfoDelphiCompile.resize(650, 500)
        ProgramInfoDelphiCompile.setModal(True)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramInfoDelphiCompile)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_4 = QtGui.QLabel(ProgramInfoDelphiCompile)
        self.label_4.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 0, 0, 1, 1)
        self.edit_log = QtGui.QPlainTextEdit(ProgramInfoDelphiCompile)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.edit_log.sizePolicy().hasHeightForWidth())
        self.edit_log.setSizePolicy(sizePolicy)
        self.edit_log.setUndoRedoEnabled(False)
        self.edit_log.setLineWrapMode(QtGui.QPlainTextEdit.NoWrap)
        self.edit_log.setReadOnly(True)
        self.edit_log.setTextInteractionFlags(QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.edit_log.setObjectName(_fromUtf8("edit_log"))
        self.gridLayout.addWidget(self.edit_log, 0, 1, 1, 1)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.button_make = QtGui.QPushButton(ProgramInfoDelphiCompile)
        self.button_make.setAutoDefault(False)
        self.button_make.setObjectName(_fromUtf8("button_make"))
        self.horizontalLayout.addWidget(self.button_make)
        self.button_clean = QtGui.QPushButton(ProgramInfoDelphiCompile)
        self.button_clean.setAutoDefault(False)
        self.button_clean.setObjectName(_fromUtf8("button_clean"))
        self.horizontalLayout.addWidget(self.button_clean)
        self.button_compile = QtGui.QPushButton(ProgramInfoDelphiCompile)
        self.button_compile.setObjectName(_fromUtf8("button_compile"))
        self.horizontalLayout.addWidget(self.button_compile)
        self.button_recompile_all = QtGui.QPushButton(ProgramInfoDelphiCompile)
        self.button_recompile_all.setObjectName(_fromUtf8("button_recompile_all"))
        self.horizontalLayout.addWidget(self.button_recompile_all)
        self.button_cancel = QtGui.QPushButton(ProgramInfoDelphiCompile)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.button_cancel.sizePolicy().hasHeightForWidth())
        self.button_cancel.setSizePolicy(sizePolicy)
        self.button_cancel.setAutoDefault(False)
        self.button_cancel.setObjectName(_fromUtf8("button_cancel"))
        self.horizontalLayout.addWidget(self.button_cancel)
        self.button_close = QtGui.QPushButton(ProgramInfoDelphiCompile)
        self.button_close.setObjectName(_fromUtf8("button_close"))
        self.horizontalLayout.addWidget(self.button_close)
        self.gridLayout.addLayout(self.horizontalLayout, 1, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.label_4.setBuddy(self.edit_log)

        self.retranslateUi(ProgramInfoDelphiCompile)
        QtCore.QMetaObject.connectSlotsByName(ProgramInfoDelphiCompile)

    def retranslateUi(self, ProgramInfoDelphiCompile):
        ProgramInfoDelphiCompile.setWindowTitle(_translate("ProgramInfoDelphiCompile", "Compile Program", None))
        self.label_4.setText(_translate("ProgramInfoDelphiCompile", "Log:", None))
        self.button_make.setText(_translate("ProgramInfoDelphiCompile", "Make", None))
        self.button_clean.setText(_translate("ProgramInfoDelphiCompile", "Clean", None))
        self.button_compile.setText(_translate("ProgramInfoDelphiCompile", "Compile", None))
        self.button_recompile_all.setText(_translate("ProgramInfoDelphiCompile", "Recompile All", None))
        self.button_cancel.setText(_translate("ProgramInfoDelphiCompile", "Cancel", None))
        self.button_close.setText(_translate("ProgramInfoDelphiCompile", "Close", None))

