# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_importexport.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabImportExport(object):
    def setupUi(self, REDTabImportExport):
        REDTabImportExport.setObjectName(_fromUtf8("REDTabImportExport"))
        REDTabImportExport.resize(579, 291)
        self.verticalLayout = QtGui.QVBoxLayout(REDTabImportExport)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.tab_widget = QtGui.QTabWidget(REDTabImportExport)
        self.tab_widget.setObjectName(_fromUtf8("tab_widget"))
        self.tab_systemlogs = REDTabImportExportSystemLogs()
        self.tab_systemlogs.setObjectName(_fromUtf8("tab_systemlogs"))
        self.tab_widget.addTab(self.tab_systemlogs, _fromUtf8(""))
        self.tab_import = REDTabImportExportImport()
        self.tab_import.setObjectName(_fromUtf8("tab_import"))
        self.tab_widget.addTab(self.tab_import, _fromUtf8(""))
        self.tab_export = REDTabImportExportExport()
        self.tab_export.setObjectName(_fromUtf8("tab_export"))
        self.tab_widget.addTab(self.tab_export, _fromUtf8(""))
        self.verticalLayout.addWidget(self.tab_widget)

        self.retranslateUi(REDTabImportExport)
        self.tab_widget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(REDTabImportExport)

    def retranslateUi(self, REDTabImportExport):
        REDTabImportExport.setWindowTitle(_translate("REDTabImportExport", "REDTabSettings", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_systemlogs), _translate("REDTabImportExport", "System Logs", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_import), _translate("REDTabImportExport", "Import", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_export), _translate("REDTabImportExport", "Export", None))

from brickv.plugin_system.plugins.red.red_tab_importexport_export import REDTabImportExportExport
from brickv.plugin_system.plugins.red.red_tab_importexport_import import REDTabImportExportImport
from brickv.plugin_system.plugins.red.red_tab_importexport_systemlogs import REDTabImportExportSystemLogs
