# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_page_files.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramPageFiles(object):
    def setupUi(self, ProgramPageFiles):
        ProgramPageFiles.setObjectName(_fromUtf8("ProgramPageFiles"))
        ProgramPageFiles.resize(465, 501)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramPageFiles)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(ProgramPageFiles)
        self.label.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.button_add_files = QtGui.QPushButton(ProgramPageFiles)
        self.button_add_files.setObjectName(_fromUtf8("button_add_files"))
        self.gridLayout.addWidget(self.button_add_files, 2, 1, 1, 1)
        self.button_remove_selected_files = QtGui.QPushButton(ProgramPageFiles)
        self.button_remove_selected_files.setObjectName(_fromUtf8("button_remove_selected_files"))
        self.gridLayout.addWidget(self.button_remove_selected_files, 2, 3, 1, 1)
        self.list_files = QtGui.QListWidget(ProgramPageFiles)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.list_files.sizePolicy().hasHeightForWidth())
        self.list_files.setSizePolicy(sizePolicy)
        self.list_files.setSelectionMode(QtGui.QAbstractItemView.ExtendedSelection)
        self.list_files.setObjectName(_fromUtf8("list_files"))
        self.gridLayout.addWidget(self.list_files, 0, 1, 1, 3)
        self.button_add_directory = QtGui.QPushButton(ProgramPageFiles)
        self.button_add_directory.setObjectName(_fromUtf8("button_add_directory"))
        self.gridLayout.addWidget(self.button_add_directory, 2, 2, 1, 1)
        self.label_files_help = QtGui.QLabel(ProgramPageFiles)
        self.label_files_help.setObjectName(_fromUtf8("label_files_help"))
        self.gridLayout.addWidget(self.label_files_help, 1, 1, 1, 3)
        self.verticalLayout.addLayout(self.gridLayout)
        self.label.setBuddy(self.list_files)

        self.retranslateUi(ProgramPageFiles)
        QtCore.QMetaObject.connectSlotsByName(ProgramPageFiles)
        ProgramPageFiles.setTabOrder(self.list_files, self.button_add_files)
        ProgramPageFiles.setTabOrder(self.button_add_files, self.button_add_directory)
        ProgramPageFiles.setTabOrder(self.button_add_directory, self.button_remove_selected_files)

    def retranslateUi(self, ProgramPageFiles):
        ProgramPageFiles.setWindowTitle(_translate("ProgramPageFiles", "Form", None))
        self.label.setText(_translate("ProgramPageFiles", "Files:", None))
        self.button_add_files.setText(_translate("ProgramPageFiles", "Add Files", None))
        self.button_remove_selected_files.setText(_translate("ProgramPageFiles", "Remove", None))
        self.button_add_directory.setText(_translate("ProgramPageFiles", "Add Directory", None))
        self.label_files_help.setText(_translate("ProgramPageFiles", "This list of files will be uploaded to the RED Brick.", None))

