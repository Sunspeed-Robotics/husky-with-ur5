# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_settings_ap_dhcp_leases_dialog.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabSettingsAPDhcpLeasesDialog(object):
    def setupUi(self, REDTabSettingsAPDhcpLeasesDialog):
        REDTabSettingsAPDhcpLeasesDialog.setObjectName(_fromUtf8("REDTabSettingsAPDhcpLeasesDialog"))
        REDTabSettingsAPDhcpLeasesDialog.resize(761, 317)
        self.gridLayout = QtGui.QGridLayout(REDTabSettingsAPDhcpLeasesDialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.tview_ap_leases = QtGui.QTreeView(REDTabSettingsAPDhcpLeasesDialog)
        self.tview_ap_leases.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.tview_ap_leases.setAlternatingRowColors(True)
        self.tview_ap_leases.setSelectionMode(QtGui.QAbstractItemView.NoSelection)
        self.tview_ap_leases.setRootIsDecorated(False)
        self.tview_ap_leases.setObjectName(_fromUtf8("tview_ap_leases"))
        self.gridLayout.addWidget(self.tview_ap_leases, 0, 0, 1, 1)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.pbutton_ap_leases_refresh = QtGui.QPushButton(REDTabSettingsAPDhcpLeasesDialog)
        self.pbutton_ap_leases_refresh.setAutoDefault(False)
        self.pbutton_ap_leases_refresh.setObjectName(_fromUtf8("pbutton_ap_leases_refresh"))
        self.horizontalLayout.addWidget(self.pbutton_ap_leases_refresh)
        self.pbutton_ap_leases_close = QtGui.QPushButton(REDTabSettingsAPDhcpLeasesDialog)
        self.pbutton_ap_leases_close.setDefault(False)
        self.pbutton_ap_leases_close.setObjectName(_fromUtf8("pbutton_ap_leases_close"))
        self.horizontalLayout.addWidget(self.pbutton_ap_leases_close)
        self.gridLayout.addLayout(self.horizontalLayout, 1, 0, 1, 1)

        self.retranslateUi(REDTabSettingsAPDhcpLeasesDialog)
        QtCore.QMetaObject.connectSlotsByName(REDTabSettingsAPDhcpLeasesDialog)
        REDTabSettingsAPDhcpLeasesDialog.setTabOrder(self.tview_ap_leases, self.pbutton_ap_leases_refresh)
        REDTabSettingsAPDhcpLeasesDialog.setTabOrder(self.pbutton_ap_leases_refresh, self.pbutton_ap_leases_close)

    def retranslateUi(self, REDTabSettingsAPDhcpLeasesDialog):
        REDTabSettingsAPDhcpLeasesDialog.setWindowTitle(_translate("REDTabSettingsAPDhcpLeasesDialog", "DHCP Leases", None))
        self.pbutton_ap_leases_refresh.setText(_translate("REDTabSettingsAPDhcpLeasesDialog", "Refresh", None))
        self.pbutton_ap_leases_close.setText(_translate("REDTabSettingsAPDhcpLeasesDialog", "Close", None))

