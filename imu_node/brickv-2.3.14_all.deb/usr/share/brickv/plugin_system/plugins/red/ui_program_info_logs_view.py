# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_info_logs_view.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramInfoLogsView(object):
    def setupUi(self, ProgramInfoLogsView):
        ProgramInfoLogsView.setObjectName(_fromUtf8("ProgramInfoLogsView"))
        ProgramInfoLogsView.resize(650, 500)
        ProgramInfoLogsView.setModal(True)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramInfoLogsView)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_4 = QtGui.QLabel(ProgramInfoLogsView)
        self.label_4.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 2, 0, 1, 1)
        self.edit_content = QtGui.QPlainTextEdit(ProgramInfoLogsView)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.edit_content.sizePolicy().hasHeightForWidth())
        self.edit_content.setSizePolicy(sizePolicy)
        self.edit_content.setUndoRedoEnabled(False)
        self.edit_content.setLineWrapMode(QtGui.QPlainTextEdit.NoWrap)
        self.edit_content.setReadOnly(True)
        self.edit_content.setTextInteractionFlags(QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.edit_content.setObjectName(_fromUtf8("edit_content"))
        self.gridLayout.addWidget(self.edit_content, 2, 1, 1, 2)
        self.label = QtGui.QLabel(ProgramInfoLogsView)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)
        self.label_date_time = QtGui.QLabel(ProgramInfoLogsView)
        self.label_date_time.setObjectName(_fromUtf8("label_date_time"))
        self.gridLayout.addWidget(self.label_date_time, 1, 1, 1, 2)
        self.progress_download = QtGui.QProgressBar(ProgramInfoLogsView)
        self.progress_download.setProperty("value", 0)
        self.progress_download.setAlignment(QtCore.Qt.AlignCenter)
        self.progress_download.setObjectName(_fromUtf8("progress_download"))
        self.gridLayout.addWidget(self.progress_download, 0, 1, 1, 2)
        self.label_download = QtGui.QLabel(ProgramInfoLogsView)
        self.label_download.setObjectName(_fromUtf8("label_download"))
        self.gridLayout.addWidget(self.label_download, 0, 0, 1, 1)
        self.button_save = QtGui.QPushButton(ProgramInfoLogsView)
        self.button_save.setAutoDefault(False)
        self.button_save.setObjectName(_fromUtf8("button_save"))
        self.gridLayout.addWidget(self.button_save, 3, 1, 1, 1)
        self.button_close = QtGui.QPushButton(ProgramInfoLogsView)
        self.button_close.setObjectName(_fromUtf8("button_close"))
        self.gridLayout.addWidget(self.button_close, 3, 2, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.label_4.setBuddy(self.edit_content)

        self.retranslateUi(ProgramInfoLogsView)
        QtCore.QMetaObject.connectSlotsByName(ProgramInfoLogsView)

    def retranslateUi(self, ProgramInfoLogsView):
        ProgramInfoLogsView.setWindowTitle(_translate("ProgramInfoLogsView", "View Log", None))
        self.label_4.setText(_translate("ProgramInfoLogsView", "Content:", None))
        self.label.setText(_translate("ProgramInfoLogsView", "Date / Time:", None))
        self.label_date_time.setText(_translate("ProgramInfoLogsView", "<date-time>", None))
        self.label_download.setText(_translate("ProgramInfoLogsView", "Download:", None))
        self.button_save.setText(_translate("ProgramInfoLogsView", "Save", None))
        self.button_close.setText(_translate("ProgramInfoLogsView", "Close", None))

