# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_settings_mobile_internet_provider_preset_dialog.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabSettingsMobileInternetProviderPresetDialog(object):
    def setupUi(self, REDTabSettingsMobileInternetProviderPresetDialog):
        REDTabSettingsMobileInternetProviderPresetDialog.setObjectName(_fromUtf8("REDTabSettingsMobileInternetProviderPresetDialog"))
        REDTabSettingsMobileInternetProviderPresetDialog.resize(434, 225)
        self.gridLayout = QtGui.QGridLayout(REDTabSettingsMobileInternetProviderPresetDialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.pbutton_mi_presets_select = QtGui.QPushButton(REDTabSettingsMobileInternetProviderPresetDialog)
        self.pbutton_mi_presets_select.setObjectName(_fromUtf8("pbutton_mi_presets_select"))
        self.gridLayout.addWidget(self.pbutton_mi_presets_select, 1, 0, 1, 1)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 2, 0, 1, 2)
        self.gridLayout_2 = QtGui.QGridLayout()
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.line = QtGui.QFrame(REDTabSettingsMobileInternetProviderPresetDialog)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout_2.addWidget(self.line, 4, 0, 1, 2)
        self.label_mi_preview_apn = QtGui.QLabel(REDTabSettingsMobileInternetProviderPresetDialog)
        self.label_mi_preview_apn.setObjectName(_fromUtf8("label_mi_preview_apn"))
        self.gridLayout_2.addWidget(self.label_mi_preview_apn, 0, 1, 1, 1)
        self.label_2 = QtGui.QLabel(REDTabSettingsMobileInternetProviderPresetDialog)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout_2.addWidget(self.label_2, 6, 0, 1, 1)
        self.label_6 = QtGui.QLabel(REDTabSettingsMobileInternetProviderPresetDialog)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.gridLayout_2.addWidget(self.label_6, 0, 0, 1, 1)
        self.label_7 = QtGui.QLabel(REDTabSettingsMobileInternetProviderPresetDialog)
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.gridLayout_2.addWidget(self.label_7, 1, 0, 1, 1)
        self.label_4 = QtGui.QLabel(REDTabSettingsMobileInternetProviderPresetDialog)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout_2.addWidget(self.label_4, 7, 0, 1, 1)
        self.label = QtGui.QLabel(REDTabSettingsMobileInternetProviderPresetDialog)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_2.addWidget(self.label, 5, 0, 1, 1)
        self.cbox_mi_presets_plan = QtGui.QComboBox(REDTabSettingsMobileInternetProviderPresetDialog)
        self.cbox_mi_presets_plan.setObjectName(_fromUtf8("cbox_mi_presets_plan"))
        self.gridLayout_2.addWidget(self.cbox_mi_presets_plan, 7, 1, 1, 1)
        self.label_mi_preview_password = QtGui.QLabel(REDTabSettingsMobileInternetProviderPresetDialog)
        self.label_mi_preview_password.setObjectName(_fromUtf8("label_mi_preview_password"))
        self.gridLayout_2.addWidget(self.label_mi_preview_password, 2, 1, 1, 1)
        self.label_mi_preview_username = QtGui.QLabel(REDTabSettingsMobileInternetProviderPresetDialog)
        self.label_mi_preview_username.setObjectName(_fromUtf8("label_mi_preview_username"))
        self.gridLayout_2.addWidget(self.label_mi_preview_username, 1, 1, 1, 1)
        self.cbox_mi_presets_country = QtGui.QComboBox(REDTabSettingsMobileInternetProviderPresetDialog)
        self.cbox_mi_presets_country.setObjectName(_fromUtf8("cbox_mi_presets_country"))
        self.gridLayout_2.addWidget(self.cbox_mi_presets_country, 5, 1, 1, 1)
        self.cbox_mi_presets_provider = QtGui.QComboBox(REDTabSettingsMobileInternetProviderPresetDialog)
        self.cbox_mi_presets_provider.setObjectName(_fromUtf8("cbox_mi_presets_provider"))
        self.gridLayout_2.addWidget(self.cbox_mi_presets_provider, 6, 1, 1, 1)
        self.label_5 = QtGui.QLabel(REDTabSettingsMobileInternetProviderPresetDialog)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridLayout_2.addWidget(self.label_5, 3, 0, 1, 1)
        self.label_8 = QtGui.QLabel(REDTabSettingsMobileInternetProviderPresetDialog)
        self.label_8.setObjectName(_fromUtf8("label_8"))
        self.gridLayout_2.addWidget(self.label_8, 2, 0, 1, 1)
        self.label_mi_preview_dial = QtGui.QLabel(REDTabSettingsMobileInternetProviderPresetDialog)
        self.label_mi_preview_dial.setObjectName(_fromUtf8("label_mi_preview_dial"))
        self.gridLayout_2.addWidget(self.label_mi_preview_dial, 3, 1, 1, 1)
        self.gridLayout.addLayout(self.gridLayout_2, 0, 0, 1, 2)
        self.pbutton_mi_presets_close = QtGui.QPushButton(REDTabSettingsMobileInternetProviderPresetDialog)
        self.pbutton_mi_presets_close.setObjectName(_fromUtf8("pbutton_mi_presets_close"))
        self.gridLayout.addWidget(self.pbutton_mi_presets_close, 1, 1, 1, 1)

        self.retranslateUi(REDTabSettingsMobileInternetProviderPresetDialog)
        QtCore.QMetaObject.connectSlotsByName(REDTabSettingsMobileInternetProviderPresetDialog)
        REDTabSettingsMobileInternetProviderPresetDialog.setTabOrder(self.cbox_mi_presets_country, self.cbox_mi_presets_provider)
        REDTabSettingsMobileInternetProviderPresetDialog.setTabOrder(self.cbox_mi_presets_provider, self.cbox_mi_presets_plan)
        REDTabSettingsMobileInternetProviderPresetDialog.setTabOrder(self.cbox_mi_presets_plan, self.pbutton_mi_presets_select)
        REDTabSettingsMobileInternetProviderPresetDialog.setTabOrder(self.pbutton_mi_presets_select, self.pbutton_mi_presets_close)

    def retranslateUi(self, REDTabSettingsMobileInternetProviderPresetDialog):
        REDTabSettingsMobileInternetProviderPresetDialog.setWindowTitle(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "Select Provider Preset", None))
        self.pbutton_mi_presets_select.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "Select", None))
        self.label_mi_preview_apn.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "-", None))
        self.label_2.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "Provider:", None))
        self.label_6.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "APN:", None))
        self.label_7.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "Username:", None))
        self.label_4.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "Plan:", None))
        self.label.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "Country:", None))
        self.label_mi_preview_password.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "-", None))
        self.label_mi_preview_username.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "-", None))
        self.label_5.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "Dial:", None))
        self.label_8.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "Password:", None))
        self.label_mi_preview_dial.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "-", None))
        self.pbutton_mi_presets_close.setText(_translate("REDTabSettingsMobileInternetProviderPresetDialog", "Close", None))

