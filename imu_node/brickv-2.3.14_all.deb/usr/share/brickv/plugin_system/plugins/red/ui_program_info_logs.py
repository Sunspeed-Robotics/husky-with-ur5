# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_info_logs.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramInfoLogs(object):
    def setupUi(self, ProgramInfoLogs):
        ProgramInfoLogs.setObjectName(_fromUtf8("ProgramInfoLogs"))
        ProgramInfoLogs.resize(475, 489)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramInfoLogs)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.tree_logs = QtGui.QTreeView(ProgramInfoLogs)
        self.tree_logs.setMinimumSize(QtCore.QSize(0, 300))
        self.tree_logs.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.tree_logs.setSelectionMode(QtGui.QAbstractItemView.ExtendedSelection)
        self.tree_logs.setSortingEnabled(True)
        self.tree_logs.setObjectName(_fromUtf8("tree_logs"))
        self.gridLayout.addWidget(self.tree_logs, 0, 0, 1, 3)
        self.button_download_logs = QtGui.QPushButton(ProgramInfoLogs)
        self.button_download_logs.setObjectName(_fromUtf8("button_download_logs"))
        self.gridLayout.addWidget(self.button_download_logs, 2, 0, 1, 1)
        self.button_delete_logs = QtGui.QPushButton(ProgramInfoLogs)
        self.button_delete_logs.setObjectName(_fromUtf8("button_delete_logs"))
        self.gridLayout.addWidget(self.button_delete_logs, 2, 2, 1, 1)
        self.button_view_log = QtGui.QPushButton(ProgramInfoLogs)
        self.button_view_log.setObjectName(_fromUtf8("button_view_log"))
        self.gridLayout.addWidget(self.button_view_log, 2, 1, 1, 1)
        self.label_error = QtGui.QLabel(ProgramInfoLogs)
        self.label_error.setWordWrap(True)
        self.label_error.setObjectName(_fromUtf8("label_error"))
        self.gridLayout.addWidget(self.label_error, 1, 0, 1, 3)
        self.verticalLayout.addLayout(self.gridLayout)

        self.retranslateUi(ProgramInfoLogs)
        QtCore.QMetaObject.connectSlotsByName(ProgramInfoLogs)
        ProgramInfoLogs.setTabOrder(self.tree_logs, self.button_download_logs)
        ProgramInfoLogs.setTabOrder(self.button_download_logs, self.button_view_log)
        ProgramInfoLogs.setTabOrder(self.button_view_log, self.button_delete_logs)

    def retranslateUi(self, ProgramInfoLogs):
        ProgramInfoLogs.setWindowTitle(_translate("ProgramInfoLogs", "Form", None))
        self.button_download_logs.setText(_translate("ProgramInfoLogs", "Download", None))
        self.button_delete_logs.setText(_translate("ProgramInfoLogs", "Delete", None))
        self.button_view_log.setText(_translate("ProgramInfoLogs", "View", None))
        self.label_error.setText(_translate("ProgramInfoLogs", "<error>", None))

