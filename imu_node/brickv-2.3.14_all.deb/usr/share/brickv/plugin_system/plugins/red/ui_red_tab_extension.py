# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_extension.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabExtension(object):
    def setupUi(self, REDTabExtension):
        REDTabExtension.setObjectName(_fromUtf8("REDTabExtension"))
        REDTabExtension.resize(606, 443)
        self.horizontalLayout = QtGui.QHBoxLayout(REDTabExtension)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.label_status = QtGui.QLabel(REDTabExtension)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_status.sizePolicy().hasHeightForWidth())
        self.label_status.setSizePolicy(sizePolicy)
        self.label_status.setAlignment(QtCore.Qt.AlignCenter)
        self.label_status.setObjectName(_fromUtf8("label_status"))
        self.verticalLayout.addWidget(self.label_status)
        self.tab_widget = QtGui.QTabWidget(REDTabExtension)
        self.tab_widget.setObjectName(_fromUtf8("tab_widget"))
        self.tab = QtGui.QWidget()
        self.tab.setObjectName(_fromUtf8("tab"))
        self.tab_widget.addTab(self.tab, _fromUtf8(""))
        self.verticalLayout.addWidget(self.tab_widget)
        self.horizontalLayout.addLayout(self.verticalLayout)

        self.retranslateUi(REDTabExtension)
        QtCore.QMetaObject.connectSlotsByName(REDTabExtension)

    def retranslateUi(self, REDTabExtension):
        REDTabExtension.setWindowTitle(_translate("REDTabExtension", "REDTabExtension", None))
        self.label_status.setText(_translate("REDTabExtension", "Discovering Extensions...", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab), _translate("REDTabExtension", "dummy", None))

