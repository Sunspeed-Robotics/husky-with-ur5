# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_info_files_permissions.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramInfoFilesPermissions(object):
    def setupUi(self, ProgramInfoFilesPermissions):
        ProgramInfoFilesPermissions.setObjectName(_fromUtf8("ProgramInfoFilesPermissions"))
        ProgramInfoFilesPermissions.resize(352, 149)
        ProgramInfoFilesPermissions.setModal(True)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramInfoFilesPermissions)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_4 = QtGui.QLabel(ProgramInfoFilesPermissions)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 2, 0, 1, 1)
        self.label = QtGui.QLabel(ProgramInfoFilesPermissions)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.label_2 = QtGui.QLabel(ProgramInfoFilesPermissions)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.button_okay = QtGui.QPushButton(ProgramInfoFilesPermissions)
        self.button_okay.setAutoDefault(False)
        self.button_okay.setObjectName(_fromUtf8("button_okay"))
        self.horizontalLayout.addWidget(self.button_okay)
        self.button_cancel = QtGui.QPushButton(ProgramInfoFilesPermissions)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.button_cancel.sizePolicy().hasHeightForWidth())
        self.button_cancel.setSizePolicy(sizePolicy)
        self.button_cancel.setAutoDefault(False)
        self.button_cancel.setObjectName(_fromUtf8("button_cancel"))
        self.horizontalLayout.addWidget(self.button_cancel)
        self.gridLayout.addLayout(self.horizontalLayout, 4, 1, 1, 3)
        self.check_owner_read = QtGui.QCheckBox(ProgramInfoFilesPermissions)
        self.check_owner_read.setObjectName(_fromUtf8("check_owner_read"))
        self.gridLayout.addWidget(self.check_owner_read, 0, 1, 1, 1)
        self.check_owner_write = QtGui.QCheckBox(ProgramInfoFilesPermissions)
        self.check_owner_write.setObjectName(_fromUtf8("check_owner_write"))
        self.gridLayout.addWidget(self.check_owner_write, 0, 2, 1, 1)
        self.check_group_read = QtGui.QCheckBox(ProgramInfoFilesPermissions)
        self.check_group_read.setObjectName(_fromUtf8("check_group_read"))
        self.gridLayout.addWidget(self.check_group_read, 1, 1, 1, 1)
        self.check_other_read = QtGui.QCheckBox(ProgramInfoFilesPermissions)
        self.check_other_read.setObjectName(_fromUtf8("check_other_read"))
        self.gridLayout.addWidget(self.check_other_read, 2, 1, 1, 1)
        self.check_group_write = QtGui.QCheckBox(ProgramInfoFilesPermissions)
        self.check_group_write.setObjectName(_fromUtf8("check_group_write"))
        self.gridLayout.addWidget(self.check_group_write, 1, 2, 1, 1)
        self.check_other_write = QtGui.QCheckBox(ProgramInfoFilesPermissions)
        self.check_other_write.setObjectName(_fromUtf8("check_other_write"))
        self.gridLayout.addWidget(self.check_other_write, 2, 2, 1, 1)
        self.check_owner_execute = QtGui.QCheckBox(ProgramInfoFilesPermissions)
        self.check_owner_execute.setObjectName(_fromUtf8("check_owner_execute"))
        self.gridLayout.addWidget(self.check_owner_execute, 0, 3, 1, 1)
        self.check_group_execute = QtGui.QCheckBox(ProgramInfoFilesPermissions)
        self.check_group_execute.setObjectName(_fromUtf8("check_group_execute"))
        self.gridLayout.addWidget(self.check_group_execute, 1, 3, 1, 1)
        self.check_other_execute = QtGui.QCheckBox(ProgramInfoFilesPermissions)
        self.check_other_execute.setObjectName(_fromUtf8("check_other_execute"))
        self.gridLayout.addWidget(self.check_other_execute, 2, 3, 1, 1)
        spacerItem = QtGui.QSpacerItem(20, 0, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 3, 2, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)

        self.retranslateUi(ProgramInfoFilesPermissions)
        QtCore.QMetaObject.connectSlotsByName(ProgramInfoFilesPermissions)

    def retranslateUi(self, ProgramInfoFilesPermissions):
        ProgramInfoFilesPermissions.setWindowTitle(_translate("ProgramInfoFilesPermissions", "Change Permissions", None))
        self.label_4.setText(_translate("ProgramInfoFilesPermissions", "Other:", None))
        self.label.setText(_translate("ProgramInfoFilesPermissions", "Owner:", None))
        self.label_2.setText(_translate("ProgramInfoFilesPermissions", "Group:", None))
        self.button_okay.setText(_translate("ProgramInfoFilesPermissions", "Okay", None))
        self.button_cancel.setText(_translate("ProgramInfoFilesPermissions", "Cancel", None))
        self.check_owner_read.setText(_translate("ProgramInfoFilesPermissions", "Read", None))
        self.check_owner_write.setText(_translate("ProgramInfoFilesPermissions", "Write", None))
        self.check_group_read.setText(_translate("ProgramInfoFilesPermissions", "Read", None))
        self.check_other_read.setText(_translate("ProgramInfoFilesPermissions", "Read", None))
        self.check_group_write.setText(_translate("ProgramInfoFilesPermissions", "Write", None))
        self.check_other_write.setText(_translate("ProgramInfoFilesPermissions", "Write", None))
        self.check_owner_execute.setText(_translate("ProgramInfoFilesPermissions", "Execute", None))
        self.check_group_execute.setText(_translate("ProgramInfoFilesPermissions", "Execute", None))
        self.check_other_execute.setText(_translate("ProgramInfoFilesPermissions", "Execute", None))

