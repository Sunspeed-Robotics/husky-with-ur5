# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_importexport_systemlogs.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabImportExportSystemLogs(object):
    def setupUi(self, REDTabImportExportSystemLogs):
        REDTabImportExportSystemLogs.setObjectName(_fromUtf8("REDTabImportExportSystemLogs"))
        REDTabImportExportSystemLogs.resize(648, 514)
        self.verticalLayout = QtGui.QVBoxLayout(REDTabImportExportSystemLogs)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.combo_log = QtGui.QComboBox(REDTabImportExportSystemLogs)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.combo_log.sizePolicy().hasHeightForWidth())
        self.combo_log.setSizePolicy(sizePolicy)
        self.combo_log.setInsertPolicy(QtGui.QComboBox.NoInsert)
        self.combo_log.setObjectName(_fromUtf8("combo_log"))
        self.gridLayout.addWidget(self.combo_log, 0, 0, 1, 2)
        self.button_refresh = QtGui.QPushButton(REDTabImportExportSystemLogs)
        self.button_refresh.setObjectName(_fromUtf8("button_refresh"))
        self.gridLayout.addWidget(self.button_refresh, 4, 0, 1, 1)
        self.button_save = QtGui.QPushButton(REDTabImportExportSystemLogs)
        self.button_save.setObjectName(_fromUtf8("button_save"))
        self.gridLayout.addWidget(self.button_save, 4, 1, 1, 1)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.progress_download = QtGui.QProgressBar(REDTabImportExportSystemLogs)
        self.progress_download.setProperty("value", 0)
        self.progress_download.setAlignment(QtCore.Qt.AlignCenter)
        self.progress_download.setObjectName(_fromUtf8("progress_download"))
        self.horizontalLayout.addWidget(self.progress_download)
        self.button_cancel = QtGui.QPushButton(REDTabImportExportSystemLogs)
        self.button_cancel.setObjectName(_fromUtf8("button_cancel"))
        self.horizontalLayout.addWidget(self.button_cancel)
        self.gridLayout.addLayout(self.horizontalLayout, 2, 0, 1, 2)
        self.label_download = QtGui.QLabel(REDTabImportExportSystemLogs)
        self.label_download.setWordWrap(True)
        self.label_download.setObjectName(_fromUtf8("label_download"))
        self.gridLayout.addWidget(self.label_download, 1, 0, 1, 2)
        self.stacked_container = QtGui.QStackedWidget(REDTabImportExportSystemLogs)
        self.stacked_container.setObjectName(_fromUtf8("stacked_container"))
        self.page_dummy = QtGui.QWidget()
        self.page_dummy.setObjectName(_fromUtf8("page_dummy"))
        self.stacked_container.addWidget(self.page_dummy)
        self.gridLayout.addWidget(self.stacked_container, 3, 0, 1, 2)
        self.verticalLayout.addLayout(self.gridLayout)

        self.retranslateUi(REDTabImportExportSystemLogs)
        QtCore.QMetaObject.connectSlotsByName(REDTabImportExportSystemLogs)
        REDTabImportExportSystemLogs.setTabOrder(self.combo_log, self.button_cancel)
        REDTabImportExportSystemLogs.setTabOrder(self.button_cancel, self.button_refresh)
        REDTabImportExportSystemLogs.setTabOrder(self.button_refresh, self.button_save)

    def retranslateUi(self, REDTabImportExportSystemLogs):
        REDTabImportExportSystemLogs.setWindowTitle(_translate("REDTabImportExportSystemLogs", "Form", None))
        self.button_refresh.setText(_translate("REDTabImportExportSystemLogs", "Refresh", None))
        self.button_save.setText(_translate("REDTabImportExportSystemLogs", "Save", None))
        self.button_cancel.setText(_translate("REDTabImportExportSystemLogs", "Cancel", None))
        self.label_download.setText(_translate("REDTabImportExportSystemLogs", "<download>", None))

