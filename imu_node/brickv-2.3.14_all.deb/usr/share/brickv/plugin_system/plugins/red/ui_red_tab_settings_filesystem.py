# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_settings_filesystem.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabSettingsFileSystem(object):
    def setupUi(self, REDTabSettingsFileSystem):
        REDTabSettingsFileSystem.setObjectName(_fromUtf8("REDTabSettingsFileSystem"))
        REDTabSettingsFileSystem.resize(513, 596)
        self.verticalLayout_2 = QtGui.QVBoxLayout(REDTabSettingsFileSystem)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.scrollArea = QtGui.QScrollArea(REDTabSettingsFileSystem)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName(_fromUtf8("scrollArea"))
        self.scrollAreaWidgetContents = QtGui.QWidget()
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 493, 576))
        self.scrollAreaWidgetContents.setObjectName(_fromUtf8("scrollAreaWidgetContents"))
        self.verticalLayout = QtGui.QVBoxLayout(self.scrollAreaWidgetContents)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout_5 = QtGui.QGridLayout()
        self.gridLayout_5.setObjectName(_fromUtf8("gridLayout_5"))
        self.line_4 = QtGui.QFrame(self.scrollAreaWidgetContents)
        self.line_4.setFrameShape(QtGui.QFrame.HLine)
        self.line_4.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_4.setObjectName(_fromUtf8("line_4"))
        self.gridLayout_5.addWidget(self.line_4, 4, 0, 1, 1)
        self.horizontalLayout_13 = QtGui.QHBoxLayout()
        self.horizontalLayout_13.setObjectName(_fromUtf8("horizontalLayout_13"))
        self.pbar_fs_capacity_utilization = QtGui.QProgressBar(self.scrollAreaWidgetContents)
        self.pbar_fs_capacity_utilization.setEnabled(False)
        self.pbar_fs_capacity_utilization.setMaximum(0)
        self.pbar_fs_capacity_utilization.setProperty("value", 0)
        self.pbar_fs_capacity_utilization.setAlignment(QtCore.Qt.AlignCenter)
        self.pbar_fs_capacity_utilization.setFormat(_fromUtf8(""))
        self.pbar_fs_capacity_utilization.setObjectName(_fromUtf8("pbar_fs_capacity_utilization"))
        self.horizontalLayout_13.addWidget(self.pbar_fs_capacity_utilization)
        self.label_pbar_fs_capacity_utilization = QtGui.QLabel(self.scrollAreaWidgetContents)
        self.label_pbar_fs_capacity_utilization.setObjectName(_fromUtf8("label_pbar_fs_capacity_utilization"))
        self.horizontalLayout_13.addWidget(self.label_pbar_fs_capacity_utilization)
        self.gridLayout_5.addLayout(self.horizontalLayout_13, 2, 0, 1, 1)
        self.pbutton_fs_expand = QtGui.QPushButton(self.scrollAreaWidgetContents)
        self.pbutton_fs_expand.setEnabled(False)
        self.pbutton_fs_expand.setObjectName(_fromUtf8("pbutton_fs_expand"))
        self.gridLayout_5.addWidget(self.pbutton_fs_expand, 5, 0, 1, 1)
        self.label_fs_expand_info = QtGui.QLabel(self.scrollAreaWidgetContents)
        self.label_fs_expand_info.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_fs_expand_info.setWordWrap(True)
        self.label_fs_expand_info.setObjectName(_fromUtf8("label_fs_expand_info"))
        self.gridLayout_5.addWidget(self.label_fs_expand_info, 0, 0, 1, 1)
        self.line = QtGui.QFrame(self.scrollAreaWidgetContents)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout_5.addWidget(self.line, 1, 0, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout_5)
        spacerItem = QtGui.QSpacerItem(20, 0, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout_2.addWidget(self.scrollArea)

        self.retranslateUi(REDTabSettingsFileSystem)
        QtCore.QMetaObject.connectSlotsByName(REDTabSettingsFileSystem)
        REDTabSettingsFileSystem.setTabOrder(self.scrollArea, self.pbutton_fs_expand)

    def retranslateUi(self, REDTabSettingsFileSystem):
        REDTabSettingsFileSystem.setWindowTitle(_translate("REDTabSettingsFileSystem", "Form", None))
        self.label_pbar_fs_capacity_utilization.setText(_translate("REDTabSettingsFileSystem", "<capacity-utilization>", None))
        self.pbutton_fs_expand.setText(_translate("REDTabSettingsFileSystem", "Reboot and Expand", None))
        self.label_fs_expand_info.setText(_translate("REDTabSettingsFileSystem", "<html><body><p>Depending on the image size and the capacity of the Micro-SD card you might not be using the total capacity of the Micro-SD card. In this case expanding the file system will provide you with some extra storage space. </p><p><b>Steps:</b></p><p>1. Make sure the RED Brick is powered from a reliable power source during the expansion process and do not power it off during the expansion process. This could damage the Micro-SD card and the data in it. </p><p>2. After clicking the Expand button the RED Brick will automatically reboot and then expand the file system. This process may take a moment. Depending on the size and speed of the Micro-SD card it can take 1 to 15 minutes until the RED Brick will show up again in Brick Viewer.</p></body></html>", None))

