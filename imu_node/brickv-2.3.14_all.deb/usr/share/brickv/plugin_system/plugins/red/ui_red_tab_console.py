# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_console.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabConsole(object):
    def setupUi(self, REDTabConsole):
        REDTabConsole.setObjectName(_fromUtf8("REDTabConsole"))
        REDTabConsole.resize(682, 376)
        self.horizontalLayout = QtGui.QHBoxLayout(REDTabConsole)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.widget_dummy = QtGui.QWidget(REDTabConsole)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.widget_dummy.sizePolicy().hasHeightForWidth())
        self.widget_dummy.setSizePolicy(sizePolicy)
        self.widget_dummy.setObjectName(_fromUtf8("widget_dummy"))
        self.verticalLayout = QtGui.QVBoxLayout(self.widget_dummy)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.console_layout = QtGui.QVBoxLayout()
        self.console_layout.setObjectName(_fromUtf8("console_layout"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.label = QtGui.QLabel(self.widget_dummy)
        self.label.setObjectName(_fromUtf8("label"))
        self.horizontalLayout_2.addWidget(self.label)
        self.combo_serial_port = QtGui.QComboBox(self.widget_dummy)
        self.combo_serial_port.setObjectName(_fromUtf8("combo_serial_port"))
        self.horizontalLayout_2.addWidget(self.combo_serial_port)
        self.refresh_button = QtGui.QPushButton(self.widget_dummy)
        self.refresh_button.setObjectName(_fromUtf8("refresh_button"))
        self.horizontalLayout_2.addWidget(self.refresh_button)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)
        self.connect_button = QtGui.QPushButton(self.widget_dummy)
        self.connect_button.setObjectName(_fromUtf8("connect_button"))
        self.horizontalLayout_2.addWidget(self.connect_button)
        self.console_layout.addLayout(self.horizontalLayout_2)
        self.copy_button = QtGui.QPushButton(self.widget_dummy)
        self.copy_button.setObjectName(_fromUtf8("copy_button"))
        self.console_layout.addWidget(self.copy_button)
        spacerItem1 = QtGui.QSpacerItem(20, 492, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.console_layout.addItem(spacerItem1)
        self.verticalLayout.addLayout(self.console_layout)
        self.horizontalLayout.addWidget(self.widget_dummy)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        self.label.setBuddy(self.combo_serial_port)

        self.retranslateUi(REDTabConsole)
        QtCore.QMetaObject.connectSlotsByName(REDTabConsole)
        REDTabConsole.setTabOrder(self.combo_serial_port, self.refresh_button)
        REDTabConsole.setTabOrder(self.refresh_button, self.connect_button)
        REDTabConsole.setTabOrder(self.connect_button, self.copy_button)

    def retranslateUi(self, REDTabConsole):
        REDTabConsole.setWindowTitle(_translate("REDTabConsole", "REDTabConsole", None))
        self.label.setText(_translate("REDTabConsole", "Serial Port:", None))
        self.refresh_button.setText(_translate("REDTabConsole", "Refresh Ports", None))
        self.connect_button.setText(_translate("REDTabConsole", "Connect", None))
        self.copy_button.setText(_translate("REDTabConsole", "Copy Selection To Clipboard", None))

