# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_settings_mobile_internet_puk_dialog.ui'
#
# Created: Fri May  8 17:25:17 2015
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabSettingsMobileInternetPUKDialog(object):
    def setupUi(self, REDTabSettingsMobileInternetPUKDialog):
        REDTabSettingsMobileInternetPUKDialog.setObjectName(_fromUtf8("REDTabSettingsMobileInternetPUKDialog"))
        REDTabSettingsMobileInternetPUKDialog.resize(446, 147)
        self.gridLayout = QtGui.QGridLayout(REDTabSettingsMobileInternetPUKDialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.pbutton_mi_puk_apply = QtGui.QPushButton(REDTabSettingsMobileInternetPUKDialog)
        self.pbutton_mi_puk_apply.setObjectName(_fromUtf8("pbutton_mi_puk_apply"))
        self.gridLayout.addWidget(self.pbutton_mi_puk_apply, 1, 0, 1, 1)
        self.pbutton_mi_puk_cancel = QtGui.QPushButton(REDTabSettingsMobileInternetPUKDialog)
        self.pbutton_mi_puk_cancel.setObjectName(_fromUtf8("pbutton_mi_puk_cancel"))
        self.gridLayout.addWidget(self.pbutton_mi_puk_cancel, 1, 1, 1, 1)
        self.formLayout = QtGui.QFormLayout()
        self.formLayout.setObjectName(_fromUtf8("formLayout"))
        self.label = QtGui.QLabel(REDTabSettingsMobileInternetPUKDialog)
        self.label.setObjectName(_fromUtf8("label"))
        self.formLayout.setWidget(0, QtGui.QFormLayout.LabelRole, self.label)
        self.label_2 = QtGui.QLabel(REDTabSettingsMobileInternetPUKDialog)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.formLayout.setWidget(2, QtGui.QFormLayout.LabelRole, self.label_2)
        self.label_4 = QtGui.QLabel(REDTabSettingsMobileInternetPUKDialog)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.formLayout.setWidget(1, QtGui.QFormLayout.FieldRole, self.label_4)
        self.label_5 = QtGui.QLabel(REDTabSettingsMobileInternetPUKDialog)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.formLayout.setWidget(3, QtGui.QFormLayout.FieldRole, self.label_5)
        self.ledit_mi_puk_pin = QtGui.QLineEdit(REDTabSettingsMobileInternetPUKDialog)
        self.ledit_mi_puk_pin.setInputMethodHints(QtCore.Qt.ImhNone)
        self.ledit_mi_puk_pin.setMaxLength(32)
        self.ledit_mi_puk_pin.setObjectName(_fromUtf8("ledit_mi_puk_pin"))
        self.formLayout.setWidget(2, QtGui.QFormLayout.FieldRole, self.ledit_mi_puk_pin)
        self.ledit_mi_puk_puk = QtGui.QLineEdit(REDTabSettingsMobileInternetPUKDialog)
        self.ledit_mi_puk_puk.setInputMethodHints(QtCore.Qt.ImhNone)
        self.ledit_mi_puk_puk.setMaxLength(32)
        self.ledit_mi_puk_puk.setObjectName(_fromUtf8("ledit_mi_puk_puk"))
        self.formLayout.setWidget(0, QtGui.QFormLayout.FieldRole, self.ledit_mi_puk_puk)
        self.gridLayout.addLayout(self.formLayout, 0, 0, 1, 2)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 2, 0, 1, 2)

        self.retranslateUi(REDTabSettingsMobileInternetPUKDialog)
        QtCore.QMetaObject.connectSlotsByName(REDTabSettingsMobileInternetPUKDialog)

    def retranslateUi(self, REDTabSettingsMobileInternetPUKDialog):
        REDTabSettingsMobileInternetPUKDialog.setWindowTitle(_translate("REDTabSettingsMobileInternetPUKDialog", "Enter PUK", None))
        self.pbutton_mi_puk_apply.setText(_translate("REDTabSettingsMobileInternetPUKDialog", "Apply", None))
        self.pbutton_mi_puk_cancel.setText(_translate("REDTabSettingsMobileInternetPUKDialog", "Cancel", None))
        self.label.setText(_translate("REDTabSettingsMobileInternetPUKDialog", "PUK:", None))
        self.label_2.setText(_translate("REDTabSettingsMobileInternetPUKDialog", "PIN:", None))
        self.label_4.setText(_translate("REDTabSettingsMobileInternetPUKDialog", "Entering wrong PUK code for ten times will block the SIM.", None))
        self.label_5.setText(_translate("REDTabSettingsMobileInternetPUKDialog", "You can choose any 4 digit PIN you want.", None))

