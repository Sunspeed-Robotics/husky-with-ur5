# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_info_ruby.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramInfoRuby(object):
    def setupUi(self, ProgramInfoRuby):
        ProgramInfoRuby.setObjectName(_fromUtf8("ProgramInfoRuby"))
        ProgramInfoRuby.resize(510, 171)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramInfoRuby)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(ProgramInfoRuby)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.label_2 = QtGui.QLabel(ProgramInfoRuby)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.label_script_file_title = QtGui.QLabel(ProgramInfoRuby)
        self.label_script_file_title.setObjectName(_fromUtf8("label_script_file_title"))
        self.gridLayout.addWidget(self.label_script_file_title, 2, 0, 1, 1)
        self.label_command_title = QtGui.QLabel(ProgramInfoRuby)
        self.label_command_title.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_command_title.setObjectName(_fromUtf8("label_command_title"))
        self.gridLayout.addWidget(self.label_command_title, 3, 0, 1, 1)
        self.label_working_directory_title = QtGui.QLabel(ProgramInfoRuby)
        self.label_working_directory_title.setObjectName(_fromUtf8("label_working_directory_title"))
        self.gridLayout.addWidget(self.label_working_directory_title, 6, 0, 1, 1)
        self.line = QtGui.QFrame(ProgramInfoRuby)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout.addWidget(self.line, 4, 0, 1, 2)
        self.label_version = QtGui.QLabel(ProgramInfoRuby)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_version.sizePolicy().hasHeightForWidth())
        self.label_version.setSizePolicy(sizePolicy)
        self.label_version.setTextFormat(QtCore.Qt.PlainText)
        self.label_version.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_version.setObjectName(_fromUtf8("label_version"))
        self.gridLayout.addWidget(self.label_version, 0, 1, 1, 1)
        self.label_start_mode = QtGui.QLabel(ProgramInfoRuby)
        self.label_start_mode.setTextFormat(QtCore.Qt.PlainText)
        self.label_start_mode.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_start_mode.setObjectName(_fromUtf8("label_start_mode"))
        self.gridLayout.addWidget(self.label_start_mode, 1, 1, 1, 1)
        self.label_script_file = QtGui.QLabel(ProgramInfoRuby)
        self.label_script_file.setTextFormat(QtCore.Qt.PlainText)
        self.label_script_file.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_script_file.setObjectName(_fromUtf8("label_script_file"))
        self.gridLayout.addWidget(self.label_script_file, 2, 1, 1, 1)
        self.label_command = QtGui.QLabel(ProgramInfoRuby)
        self.label_command.setTextFormat(QtCore.Qt.PlainText)
        self.label_command.setWordWrap(True)
        self.label_command.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_command.setObjectName(_fromUtf8("label_command"))
        self.gridLayout.addWidget(self.label_command, 3, 1, 1, 1)
        self.label_working_directory = QtGui.QLabel(ProgramInfoRuby)
        self.label_working_directory.setTextFormat(QtCore.Qt.PlainText)
        self.label_working_directory.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_working_directory.setObjectName(_fromUtf8("label_working_directory"))
        self.gridLayout.addWidget(self.label_working_directory, 6, 1, 1, 1)
        self.check_show_advanced_options = QtGui.QCheckBox(ProgramInfoRuby)
        self.check_show_advanced_options.setObjectName(_fromUtf8("check_show_advanced_options"))
        self.gridLayout.addWidget(self.check_show_advanced_options, 5, 1, 1, 1)
        self.label_options_title = QtGui.QLabel(ProgramInfoRuby)
        self.label_options_title.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_options_title.setObjectName(_fromUtf8("label_options_title"))
        self.gridLayout.addWidget(self.label_options_title, 7, 0, 1, 1)
        self.label_options = QtGui.QLabel(ProgramInfoRuby)
        self.label_options.setTextFormat(QtCore.Qt.PlainText)
        self.label_options.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_options.setObjectName(_fromUtf8("label_options"))
        self.gridLayout.addWidget(self.label_options, 7, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)

        self.retranslateUi(ProgramInfoRuby)
        QtCore.QMetaObject.connectSlotsByName(ProgramInfoRuby)

    def retranslateUi(self, ProgramInfoRuby):
        ProgramInfoRuby.setWindowTitle(_translate("ProgramInfoRuby", "Form", None))
        self.label.setText(_translate("ProgramInfoRuby", "Ruby Version:", None))
        self.label_2.setText(_translate("ProgramInfoRuby", "Start Mode:", None))
        self.label_script_file_title.setText(_translate("ProgramInfoRuby", "Script File:", None))
        self.label_command_title.setText(_translate("ProgramInfoRuby", "Command:", None))
        self.label_working_directory_title.setText(_translate("ProgramInfoRuby", "Working Directory:", None))
        self.label_version.setText(_translate("ProgramInfoRuby", "Fetching Versions...", None))
        self.label_start_mode.setText(_translate("ProgramInfoRuby", "<start-mode>", None))
        self.label_script_file.setText(_translate("ProgramInfoRuby", "<script-file>", None))
        self.label_command.setText(_translate("ProgramInfoRuby", "<command>", None))
        self.label_working_directory.setText(_translate("ProgramInfoRuby", "<working-directory>", None))
        self.check_show_advanced_options.setText(_translate("ProgramInfoRuby", "Show Advanced Options", None))
        self.label_options_title.setText(_translate("ProgramInfoRuby", "Ruby Options:", None))
        self.label_options.setText(_translate("ProgramInfoRuby", "<ruby-options>", None))

