# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_info_c_compile.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramInfoCCompile(object):
    def setupUi(self, ProgramInfoCCompile):
        ProgramInfoCCompile.setObjectName(_fromUtf8("ProgramInfoCCompile"))
        ProgramInfoCCompile.resize(650, 500)
        ProgramInfoCCompile.setModal(True)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramInfoCCompile)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_4 = QtGui.QLabel(ProgramInfoCCompile)
        self.label_4.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 0, 0, 1, 1)
        self.edit_log = QtGui.QPlainTextEdit(ProgramInfoCCompile)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.edit_log.sizePolicy().hasHeightForWidth())
        self.edit_log.setSizePolicy(sizePolicy)
        self.edit_log.setUndoRedoEnabled(False)
        self.edit_log.setLineWrapMode(QtGui.QPlainTextEdit.NoWrap)
        self.edit_log.setReadOnly(True)
        self.edit_log.setTextInteractionFlags(QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.edit_log.setObjectName(_fromUtf8("edit_log"))
        self.gridLayout.addWidget(self.edit_log, 0, 1, 1, 4)
        self.button_make = QtGui.QPushButton(ProgramInfoCCompile)
        self.button_make.setAutoDefault(False)
        self.button_make.setObjectName(_fromUtf8("button_make"))
        self.gridLayout.addWidget(self.button_make, 1, 1, 1, 1)
        self.button_clean = QtGui.QPushButton(ProgramInfoCCompile)
        self.button_clean.setAutoDefault(False)
        self.button_clean.setObjectName(_fromUtf8("button_clean"))
        self.gridLayout.addWidget(self.button_clean, 1, 2, 1, 1)
        self.button_cancel = QtGui.QPushButton(ProgramInfoCCompile)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.button_cancel.sizePolicy().hasHeightForWidth())
        self.button_cancel.setSizePolicy(sizePolicy)
        self.button_cancel.setAutoDefault(False)
        self.button_cancel.setObjectName(_fromUtf8("button_cancel"))
        self.gridLayout.addWidget(self.button_cancel, 1, 3, 1, 1)
        self.button_close = QtGui.QPushButton(ProgramInfoCCompile)
        self.button_close.setObjectName(_fromUtf8("button_close"))
        self.gridLayout.addWidget(self.button_close, 1, 4, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.label_4.setBuddy(self.edit_log)

        self.retranslateUi(ProgramInfoCCompile)
        QtCore.QMetaObject.connectSlotsByName(ProgramInfoCCompile)
        ProgramInfoCCompile.setTabOrder(self.edit_log, self.button_make)
        ProgramInfoCCompile.setTabOrder(self.button_make, self.button_clean)
        ProgramInfoCCompile.setTabOrder(self.button_clean, self.button_cancel)
        ProgramInfoCCompile.setTabOrder(self.button_cancel, self.button_close)

    def retranslateUi(self, ProgramInfoCCompile):
        ProgramInfoCCompile.setWindowTitle(_translate("ProgramInfoCCompile", "Compile Program", None))
        self.label_4.setText(_translate("ProgramInfoCCompile", "Log:", None))
        self.button_make.setText(_translate("ProgramInfoCCompile", "Make", None))
        self.button_clean.setText(_translate("ProgramInfoCCompile", "Clean", None))
        self.button_cancel.setText(_translate("ProgramInfoCCompile", "Cancel", None))
        self.button_close.setText(_translate("ProgramInfoCCompile", "Close", None))

