# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_page_schedule.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramPageSchedule(object):
    def setupUi(self, ProgramPageSchedule):
        ProgramPageSchedule.setObjectName(_fromUtf8("ProgramPageSchedule"))
        ProgramPageSchedule.resize(506, 533)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramPageSchedule)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout_4 = QtGui.QGridLayout()
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.label_4 = QtGui.QLabel(ProgramPageSchedule)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout_4.addWidget(self.label_4, 0, 0, 1, 1)
        self.combo_start_mode = QtGui.QComboBox(ProgramPageSchedule)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.combo_start_mode.sizePolicy().hasHeightForWidth())
        self.combo_start_mode.setSizePolicy(sizePolicy)
        self.combo_start_mode.setObjectName(_fromUtf8("combo_start_mode"))
        self.combo_start_mode.addItem(_fromUtf8(""))
        self.combo_start_mode.addItem(_fromUtf8(""))
        self.combo_start_mode.addItem(_fromUtf8(""))
        self.combo_start_mode.addItem(_fromUtf8(""))
        self.gridLayout_4.addWidget(self.combo_start_mode, 0, 1, 1, 1)
        self.edit_start_fields = QtGui.QLineEdit(ProgramPageSchedule)
        self.edit_start_fields.setObjectName(_fromUtf8("edit_start_fields"))
        self.gridLayout_4.addWidget(self.edit_start_fields, 2, 1, 1, 1)
        self.spin_start_interval = QtGui.QSpinBox(ProgramPageSchedule)
        self.spin_start_interval.setMinimum(1)
        self.spin_start_interval.setMaximum(2147483647)
        self.spin_start_interval.setProperty("value", 60)
        self.spin_start_interval.setObjectName(_fromUtf8("spin_start_interval"))
        self.gridLayout_4.addWidget(self.spin_start_interval, 1, 1, 1, 1)
        self.label_start_interval = QtGui.QLabel(ProgramPageSchedule)
        self.label_start_interval.setObjectName(_fromUtf8("label_start_interval"))
        self.gridLayout_4.addWidget(self.label_start_interval, 1, 0, 1, 1)
        self.label_start_fields = QtGui.QLabel(ProgramPageSchedule)
        self.label_start_fields.setObjectName(_fromUtf8("label_start_fields"))
        self.gridLayout_4.addWidget(self.label_start_fields, 2, 0, 1, 1)
        self.label_start_mode_never_help = QtGui.QLabel(ProgramPageSchedule)
        self.label_start_mode_never_help.setWordWrap(True)
        self.label_start_mode_never_help.setObjectName(_fromUtf8("label_start_mode_never_help"))
        self.gridLayout_4.addWidget(self.label_start_mode_never_help, 3, 1, 1, 1)
        self.label_start_mode_interval_help = QtGui.QLabel(ProgramPageSchedule)
        self.label_start_mode_interval_help.setWordWrap(True)
        self.label_start_mode_interval_help.setObjectName(_fromUtf8("label_start_mode_interval_help"))
        self.gridLayout_4.addWidget(self.label_start_mode_interval_help, 5, 1, 1, 1)
        self.label_start_mode_cron_help = QtGui.QLabel(ProgramPageSchedule)
        self.label_start_mode_cron_help.setWordWrap(True)
        self.label_start_mode_cron_help.setObjectName(_fromUtf8("label_start_mode_cron_help"))
        self.gridLayout_4.addWidget(self.label_start_mode_cron_help, 6, 1, 1, 1)
        self.label_start_mode_once_help = QtGui.QLabel(ProgramPageSchedule)
        self.label_start_mode_once_help.setWordWrap(True)
        self.label_start_mode_once_help.setObjectName(_fromUtf8("label_start_mode_once_help"))
        self.gridLayout_4.addWidget(self.label_start_mode_once_help, 7, 1, 1, 1)
        self.label_start_mode_always_help = QtGui.QLabel(ProgramPageSchedule)
        self.label_start_mode_always_help.setWordWrap(True)
        self.label_start_mode_always_help.setObjectName(_fromUtf8("label_start_mode_always_help"))
        self.gridLayout_4.addWidget(self.label_start_mode_always_help, 4, 1, 1, 1)
        self.label_continue_after_error_help = QtGui.QLabel(ProgramPageSchedule)
        self.label_continue_after_error_help.setWordWrap(True)
        self.label_continue_after_error_help.setObjectName(_fromUtf8("label_continue_after_error_help"))
        self.gridLayout_4.addWidget(self.label_continue_after_error_help, 10, 1, 1, 1)
        self.check_continue_after_error = QtGui.QCheckBox(ProgramPageSchedule)
        self.check_continue_after_error.setObjectName(_fromUtf8("check_continue_after_error"))
        self.gridLayout_4.addWidget(self.check_continue_after_error, 9, 1, 1, 1)
        self.line = QtGui.QFrame(ProgramPageSchedule)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout_4.addWidget(self.line, 8, 0, 1, 2)
        self.verticalLayout.addLayout(self.gridLayout_4)
        spacerItem = QtGui.QSpacerItem(20, 0, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)

        self.retranslateUi(ProgramPageSchedule)
        self.combo_start_mode.setCurrentIndex(1)
        QtCore.QMetaObject.connectSlotsByName(ProgramPageSchedule)

    def retranslateUi(self, ProgramPageSchedule):
        ProgramPageSchedule.setWindowTitle(_translate("ProgramPageSchedule", "Form", None))
        self.label_4.setText(_translate("ProgramPageSchedule", "Mode:", None))
        self.combo_start_mode.setItemText(0, _translate("ProgramPageSchedule", "Never", None))
        self.combo_start_mode.setItemText(1, _translate("ProgramPageSchedule", "Always", None))
        self.combo_start_mode.setItemText(2, _translate("ProgramPageSchedule", "Interval", None))
        self.combo_start_mode.setItemText(3, _translate("ProgramPageSchedule", "Cron", None))
        self.edit_start_fields.setText(_translate("ProgramPageSchedule", "* * * * *", None))
        self.spin_start_interval.setSuffix(_translate("ProgramPageSchedule", " seconds", None))
        self.label_start_interval.setText(_translate("ProgramPageSchedule", "Inverval:", None))
        self.label_start_fields.setText(_translate("ProgramPageSchedule", "Fields:", None))
        self.label_start_mode_never_help.setText(_translate("ProgramPageSchedule", "The program will never be started automatically.", None))
        self.label_start_mode_interval_help.setText(_translate("ProgramPageSchedule", "The program will be started automatically every <INTERVAL> seconds, if it is not running already.", None))
        self.label_start_mode_cron_help.setText(_translate("ProgramPageSchedule", "The program will be started automatically if it is not running already and the current date and time on the RED Brick matches the specified cron fields.", None))
        self.label_start_mode_once_help.setText(_translate("ProgramPageSchedule", "The program will be started once directly after its upload finished.", None))
        self.label_start_mode_always_help.setText(_translate("ProgramPageSchedule", "The program will be started automatically every time it is not running already.", None))
        self.label_continue_after_error_help.setText(_translate("ProgramPageSchedule", "If enabled then the scheduler ignores errors and continues to start the program automatically regardless of the result from the last program run. Otherwise the scheduler only starts the program automatically again if the last program run exited normally.", None))
        self.check_continue_after_error.setText(_translate("ProgramPageSchedule", "Continue After Error", None))

