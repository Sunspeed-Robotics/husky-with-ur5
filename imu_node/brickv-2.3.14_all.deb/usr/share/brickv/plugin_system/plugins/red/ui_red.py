# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_RED(object):
    def setupUi(self, RED):
        RED.setObjectName(_fromUtf8("RED"))
        RED.resize(566, 644)
        self.verticalLayout = QtGui.QVBoxLayout(RED)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.widget_discovering = QtGui.QWidget(RED)
        self.widget_discovering.setObjectName(_fromUtf8("widget_discovering"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.widget_discovering)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem)
        self.label_discovering = QtGui.QLabel(self.widget_discovering)
        self.label_discovering.setAlignment(QtCore.Qt.AlignCenter)
        self.label_discovering.setWordWrap(True)
        self.label_discovering.setObjectName(_fromUtf8("label_discovering"))
        self.verticalLayout_2.addWidget(self.label_discovering)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.button_anyway = QtGui.QPushButton(self.widget_discovering)
        self.button_anyway.setObjectName(_fromUtf8("button_anyway"))
        self.horizontalLayout.addWidget(self.button_anyway)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        spacerItem3 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem3)
        self.verticalLayout.addWidget(self.widget_discovering)
        self.tab_widget = QtGui.QTabWidget(RED)
        self.tab_widget.setTabPosition(QtGui.QTabWidget.West)
        self.tab_widget.setObjectName(_fromUtf8("tab_widget"))
        self.tab_overview = REDTabOverview()
        self.tab_overview.setObjectName(_fromUtf8("tab_overview"))
        self.tab_widget.addTab(self.tab_overview, _fromUtf8(""))
        self.tab_settings = REDTabSettings()
        self.tab_settings.setObjectName(_fromUtf8("tab_settings"))
        self.tab_widget.addTab(self.tab_settings, _fromUtf8(""))
        self.tab_program = REDTabProgram()
        self.tab_program.setObjectName(_fromUtf8("tab_program"))
        self.tab_widget.addTab(self.tab_program, _fromUtf8(""))
        self.tab_console = REDTabConsole()
        self.tab_console.setObjectName(_fromUtf8("tab_console"))
        self.tab_widget.addTab(self.tab_console, _fromUtf8(""))
        self.tab_versions = REDTabVersions()
        self.tab_versions.setObjectName(_fromUtf8("tab_versions"))
        self.tab_widget.addTab(self.tab_versions, _fromUtf8(""))
        self.tab_extension = REDTabExtension()
        self.tab_extension.setObjectName(_fromUtf8("tab_extension"))
        self.tab_widget.addTab(self.tab_extension, _fromUtf8(""))
        self.tab_importexport = REDTabImportExport()
        self.tab_importexport.setObjectName(_fromUtf8("tab_importexport"))
        self.tab_widget.addTab(self.tab_importexport, _fromUtf8(""))
        self.verticalLayout.addWidget(self.tab_widget)

        self.retranslateUi(RED)
        self.tab_widget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(RED)

    def retranslateUi(self, RED):
        RED.setWindowTitle(_translate("RED", "RED", None))
        self.label_discovering.setText(_translate("RED", "Discovering Image Version...", None))
        self.button_anyway.setText(_translate("RED", "Access RED Brick Anyway!", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_overview), _translate("RED", "Overview", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_settings), _translate("RED", "Settings", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_program), _translate("RED", "Program", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_console), _translate("RED", "Console", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_versions), _translate("RED", "Versions", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_extension), _translate("RED", "Extension", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab_importexport), _translate("RED", "Import/Export", None))

from brickv.plugin_system.plugins.red.red_tab_console import REDTabConsole
from brickv.plugin_system.plugins.red.red_tab_extension import REDTabExtension
from brickv.plugin_system.plugins.red.red_tab_importexport import REDTabImportExport
from brickv.plugin_system.plugins.red.red_tab_overview import REDTabOverview
from brickv.plugin_system.plugins.red.red_tab_program import REDTabProgram
from brickv.plugin_system.plugins.red.red_tab_settings import REDTabSettings
from brickv.plugin_system.plugins.red.red_tab_versions import REDTabVersions
