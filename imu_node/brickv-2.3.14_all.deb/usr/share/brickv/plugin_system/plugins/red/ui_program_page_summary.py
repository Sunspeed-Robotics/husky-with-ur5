# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_page_summary.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramPageSummary(object):
    def setupUi(self, ProgramPageSummary):
        ProgramPageSummary.setObjectName(_fromUtf8("ProgramPageSummary"))
        ProgramPageSummary.resize(482, 499)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramPageSummary)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(ProgramPageSummary)
        self.label.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.text_summary = QtGui.QTextBrowser(ProgramPageSummary)
        self.text_summary.setObjectName(_fromUtf8("text_summary"))
        self.gridLayout.addWidget(self.text_summary, 0, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.label.setBuddy(self.text_summary)

        self.retranslateUi(ProgramPageSummary)
        QtCore.QMetaObject.connectSlotsByName(ProgramPageSummary)

    def retranslateUi(self, ProgramPageSummary):
        ProgramPageSummary.setWindowTitle(_translate("ProgramPageSummary", "Form", None))
        self.label.setText(_translate("ProgramPageSummary", "Summary:", None))

