# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_info_c.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramInfoC(object):
    def setupUi(self, ProgramInfoC):
        ProgramInfoC.setObjectName(_fromUtf8("ProgramInfoC"))
        ProgramInfoC.resize(535, 148)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramInfoC)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_2 = QtGui.QLabel(ProgramInfoC)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 0, 0, 1, 1)
        self.label_executable_title = QtGui.QLabel(ProgramInfoC)
        self.label_executable_title.setObjectName(_fromUtf8("label_executable_title"))
        self.gridLayout.addWidget(self.label_executable_title, 1, 0, 1, 1)
        self.label_compile_from_source_title = QtGui.QLabel(ProgramInfoC)
        self.label_compile_from_source_title.setObjectName(_fromUtf8("label_compile_from_source_title"))
        self.gridLayout.addWidget(self.label_compile_from_source_title, 2, 0, 1, 1)
        self.label_working_directory_title = QtGui.QLabel(ProgramInfoC)
        self.label_working_directory_title.setObjectName(_fromUtf8("label_working_directory_title"))
        self.gridLayout.addWidget(self.label_working_directory_title, 5, 0, 1, 1)
        self.line = QtGui.QFrame(ProgramInfoC)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout.addWidget(self.line, 3, 0, 1, 2)
        self.label_start_mode = QtGui.QLabel(ProgramInfoC)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_start_mode.sizePolicy().hasHeightForWidth())
        self.label_start_mode.setSizePolicy(sizePolicy)
        self.label_start_mode.setTextFormat(QtCore.Qt.PlainText)
        self.label_start_mode.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_start_mode.setObjectName(_fromUtf8("label_start_mode"))
        self.gridLayout.addWidget(self.label_start_mode, 0, 1, 1, 1)
        self.label_executable = QtGui.QLabel(ProgramInfoC)
        self.label_executable.setTextFormat(QtCore.Qt.PlainText)
        self.label_executable.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_executable.setObjectName(_fromUtf8("label_executable"))
        self.gridLayout.addWidget(self.label_executable, 1, 1, 1, 1)
        self.label_compile_from_source = QtGui.QLabel(ProgramInfoC)
        self.label_compile_from_source.setTextFormat(QtCore.Qt.PlainText)
        self.label_compile_from_source.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_compile_from_source.setObjectName(_fromUtf8("label_compile_from_source"))
        self.gridLayout.addWidget(self.label_compile_from_source, 2, 1, 1, 1)
        self.label_working_directory = QtGui.QLabel(ProgramInfoC)
        self.label_working_directory.setTextFormat(QtCore.Qt.PlainText)
        self.label_working_directory.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_working_directory.setObjectName(_fromUtf8("label_working_directory"))
        self.gridLayout.addWidget(self.label_working_directory, 5, 1, 1, 1)
        self.check_show_advanced_options = QtGui.QCheckBox(ProgramInfoC)
        self.check_show_advanced_options.setObjectName(_fromUtf8("check_show_advanced_options"))
        self.gridLayout.addWidget(self.check_show_advanced_options, 4, 1, 1, 1)
        self.label_make_options_title = QtGui.QLabel(ProgramInfoC)
        self.label_make_options_title.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_make_options_title.setObjectName(_fromUtf8("label_make_options_title"))
        self.gridLayout.addWidget(self.label_make_options_title, 6, 0, 1, 1)
        self.label_make_options = QtGui.QLabel(ProgramInfoC)
        self.label_make_options.setTextFormat(QtCore.Qt.PlainText)
        self.label_make_options.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse|QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.label_make_options.setObjectName(_fromUtf8("label_make_options"))
        self.gridLayout.addWidget(self.label_make_options, 6, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)

        self.retranslateUi(ProgramInfoC)
        QtCore.QMetaObject.connectSlotsByName(ProgramInfoC)

    def retranslateUi(self, ProgramInfoC):
        ProgramInfoC.setWindowTitle(_translate("ProgramInfoC", "Form", None))
        self.label_2.setText(_translate("ProgramInfoC", "Start Mode:", None))
        self.label_executable_title.setText(_translate("ProgramInfoC", "Executable:", None))
        self.label_compile_from_source_title.setText(_translate("ProgramInfoC", "Compile From Source:", None))
        self.label_working_directory_title.setText(_translate("ProgramInfoC", "Working Directory:", None))
        self.label_start_mode.setText(_translate("ProgramInfoC", "<start-mode>", None))
        self.label_executable.setText(_translate("ProgramInfoC", "<executable>", None))
        self.label_compile_from_source.setText(_translate("ProgramInfoC", "<compile-from-source>", None))
        self.label_working_directory.setText(_translate("ProgramInfoC", "<working-directory>", None))
        self.check_show_advanced_options.setText(_translate("ProgramInfoC", "Show Advanced Options", None))
        self.label_make_options_title.setText(_translate("ProgramInfoC", "Make Options:", None))
        self.label_make_options.setText(_translate("ProgramInfoC", "<make-options>", None))

