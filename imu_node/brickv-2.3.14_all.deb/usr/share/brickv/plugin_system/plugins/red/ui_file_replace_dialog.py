# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/file_replace_dialog.ui'
#
# Created: Tue Nov 25 10:07:21 2014
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_FileReplaceDialog(object):
    def setupUi(self, FileReplaceDialog):
        FileReplaceDialog.setObjectName(_fromUtf8("FileReplaceDialog"))
        FileReplaceDialog.resize(527, 431)
        self.verticalLayout = QtGui.QVBoxLayout(FileReplaceDialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_title = QtGui.QLabel(FileReplaceDialog)
        self.label_title.setObjectName(_fromUtf8("label_title"))
        self.gridLayout.addWidget(self.label_title, 0, 0, 1, 2)
        self.label = QtGui.QLabel(FileReplaceDialog)
        self.label.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 2, 0, 2, 1)
        self.label_3 = QtGui.QLabel(FileReplaceDialog)
        self.label_3.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 4, 0, 2, 1)
        self.label_original_size = QtGui.QLabel(FileReplaceDialog)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_original_size.sizePolicy().hasHeightForWidth())
        self.label_original_size.setSizePolicy(sizePolicy)
        self.label_original_size.setObjectName(_fromUtf8("label_original_size"))
        self.gridLayout.addWidget(self.label_original_size, 2, 1, 1, 1)
        self.label_original_last_modified = QtGui.QLabel(FileReplaceDialog)
        self.label_original_last_modified.setObjectName(_fromUtf8("label_original_last_modified"))
        self.gridLayout.addWidget(self.label_original_last_modified, 3, 1, 1, 1)
        self.label_replacement_last_modified = QtGui.QLabel(FileReplaceDialog)
        self.label_replacement_last_modified.setObjectName(_fromUtf8("label_replacement_last_modified"))
        self.gridLayout.addWidget(self.label_replacement_last_modified, 5, 1, 1, 1)
        self.check_remember = QtGui.QCheckBox(FileReplaceDialog)
        self.check_remember.setObjectName(_fromUtf8("check_remember"))
        self.gridLayout.addWidget(self.check_remember, 10, 0, 1, 2)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.button_replace = QtGui.QPushButton(FileReplaceDialog)
        self.button_replace.setObjectName(_fromUtf8("button_replace"))
        self.horizontalLayout.addWidget(self.button_replace)
        self.button_rename = QtGui.QPushButton(FileReplaceDialog)
        self.button_rename.setObjectName(_fromUtf8("button_rename"))
        self.horizontalLayout.addWidget(self.button_rename)
        self.button_skip = QtGui.QPushButton(FileReplaceDialog)
        self.button_skip.setObjectName(_fromUtf8("button_skip"))
        self.horizontalLayout.addWidget(self.button_skip)
        self.button_cancel = QtGui.QPushButton(FileReplaceDialog)
        self.button_cancel.setObjectName(_fromUtf8("button_cancel"))
        self.horizontalLayout.addWidget(self.button_cancel)
        self.gridLayout.addLayout(self.horizontalLayout, 12, 0, 1, 2)
        self.label_new_name = QtGui.QLabel(FileReplaceDialog)
        self.label_new_name.setObjectName(_fromUtf8("label_new_name"))
        self.gridLayout.addWidget(self.label_new_name, 8, 0, 1, 1)
        self.label_replacement_size = QtGui.QLabel(FileReplaceDialog)
        self.label_replacement_size.setObjectName(_fromUtf8("label_replacement_size"))
        self.gridLayout.addWidget(self.label_replacement_size, 4, 1, 1, 1)
        self.check_rename = QtGui.QCheckBox(FileReplaceDialog)
        self.check_rename.setObjectName(_fromUtf8("check_rename"))
        self.gridLayout.addWidget(self.check_rename, 7, 0, 1, 2)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.edit_new_name = QtGui.QLineEdit(FileReplaceDialog)
        self.edit_new_name.setObjectName(_fromUtf8("edit_new_name"))
        self.horizontalLayout_2.addWidget(self.edit_new_name)
        self.button_reset_new_name = QtGui.QPushButton(FileReplaceDialog)
        self.button_reset_new_name.setObjectName(_fromUtf8("button_reset_new_name"))
        self.horizontalLayout_2.addWidget(self.button_reset_new_name)
        self.gridLayout.addLayout(self.horizontalLayout_2, 8, 1, 1, 1)
        spacerItem1 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem1, 11, 1, 1, 1)
        self.label_2 = QtGui.QLabel(FileReplaceDialog)
        self.label_2.setText(_fromUtf8(""))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 1, 1, 1)
        self.label_4 = QtGui.QLabel(FileReplaceDialog)
        self.label_4.setText(_fromUtf8(""))
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 6, 1, 1, 1)
        self.label_5 = QtGui.QLabel(FileReplaceDialog)
        self.label_5.setText(_fromUtf8(""))
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridLayout.addWidget(self.label_5, 9, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)

        self.retranslateUi(FileReplaceDialog)
        QtCore.QMetaObject.connectSlotsByName(FileReplaceDialog)

    def retranslateUi(self, FileReplaceDialog):
        FileReplaceDialog.setWindowTitle(_translate("FileReplaceDialog", "Dialog", None))
        self.label_title.setText(_translate("FileReplaceDialog", "A file named \'<FILE>\' already exists in \'<DIRECTORY>\'.", None))
        self.label.setText(_translate("FileReplaceDialog", "Original:", None))
        self.label_3.setText(_translate("FileReplaceDialog", "Replacement:", None))
        self.label_original_size.setText(_translate("FileReplaceDialog", "<original-size>", None))
        self.label_original_last_modified.setText(_translate("FileReplaceDialog", "<original-last-modified>", None))
        self.label_replacement_last_modified.setText(_translate("FileReplaceDialog", "<replacement-last-modified>", None))
        self.check_remember.setText(_translate("FileReplaceDialog", "Remember decision for other files", None))
        self.button_replace.setText(_translate("FileReplaceDialog", "Replace", None))
        self.button_rename.setText(_translate("FileReplaceDialog", "Rename", None))
        self.button_skip.setText(_translate("FileReplaceDialog", "Skip", None))
        self.button_cancel.setText(_translate("FileReplaceDialog", "Cancel", None))
        self.label_new_name.setText(_translate("FileReplaceDialog", "New Name:", None))
        self.label_replacement_size.setText(_translate("FileReplaceDialog", "<replacement-size>", None))
        self.check_rename.setText(_translate("FileReplaceDialog", "Save replacement with a new name instead", None))
        self.button_reset_new_name.setText(_translate("FileReplaceDialog", "Reset", None))

