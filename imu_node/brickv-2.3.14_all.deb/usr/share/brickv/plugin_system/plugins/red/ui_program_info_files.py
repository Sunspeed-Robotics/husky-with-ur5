# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_info_files.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramInfoFiles(object):
    def setupUi(self, ProgramInfoFiles):
        ProgramInfoFiles.setObjectName(_fromUtf8("ProgramInfoFiles"))
        ProgramInfoFiles.resize(527, 476)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramInfoFiles)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.tree_files = QtGui.QTreeView(ProgramInfoFiles)
        self.tree_files.setMinimumSize(QtCore.QSize(0, 300))
        self.tree_files.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.tree_files.setSelectionMode(QtGui.QAbstractItemView.ExtendedSelection)
        self.tree_files.setSortingEnabled(True)
        self.tree_files.setObjectName(_fromUtf8("tree_files"))
        self.gridLayout.addWidget(self.tree_files, 0, 0, 1, 5)
        self.button_upload_files = QtGui.QPushButton(ProgramInfoFiles)
        self.button_upload_files.setObjectName(_fromUtf8("button_upload_files"))
        self.gridLayout.addWidget(self.button_upload_files, 2, 0, 1, 1)
        self.button_download_files = QtGui.QPushButton(ProgramInfoFiles)
        self.button_download_files.setObjectName(_fromUtf8("button_download_files"))
        self.gridLayout.addWidget(self.button_download_files, 2, 1, 1, 1)
        self.button_rename_file = QtGui.QPushButton(ProgramInfoFiles)
        self.button_rename_file.setObjectName(_fromUtf8("button_rename_file"))
        self.gridLayout.addWidget(self.button_rename_file, 2, 2, 1, 1)
        self.button_delete_files = QtGui.QPushButton(ProgramInfoFiles)
        self.button_delete_files.setObjectName(_fromUtf8("button_delete_files"))
        self.gridLayout.addWidget(self.button_delete_files, 2, 4, 1, 1)
        self.label_error = QtGui.QLabel(ProgramInfoFiles)
        self.label_error.setWordWrap(True)
        self.label_error.setObjectName(_fromUtf8("label_error"))
        self.gridLayout.addWidget(self.label_error, 1, 0, 1, 5)
        self.button_change_file_permissions = QtGui.QPushButton(ProgramInfoFiles)
        self.button_change_file_permissions.setObjectName(_fromUtf8("button_change_file_permissions"))
        self.gridLayout.addWidget(self.button_change_file_permissions, 2, 3, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)

        self.retranslateUi(ProgramInfoFiles)
        QtCore.QMetaObject.connectSlotsByName(ProgramInfoFiles)

    def retranslateUi(self, ProgramInfoFiles):
        ProgramInfoFiles.setWindowTitle(_translate("ProgramInfoFiles", "Form", None))
        self.button_upload_files.setText(_translate("ProgramInfoFiles", "Upload", None))
        self.button_download_files.setText(_translate("ProgramInfoFiles", "Download", None))
        self.button_rename_file.setText(_translate("ProgramInfoFiles", "Rename", None))
        self.button_delete_files.setText(_translate("ProgramInfoFiles", "Delete", None))
        self.label_error.setText(_translate("ProgramInfoFiles", "<error>", None))
        self.button_change_file_permissions.setText(_translate("ProgramInfoFiles", "Permissions", None))

