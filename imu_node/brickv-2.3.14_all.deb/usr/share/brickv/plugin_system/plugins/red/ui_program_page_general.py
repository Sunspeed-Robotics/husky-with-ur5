# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/program_page_general.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProgramPageGeneral(object):
    def setupUi(self, ProgramPageGeneral):
        ProgramPageGeneral.setObjectName(_fromUtf8("ProgramPageGeneral"))
        ProgramPageGeneral.resize(593, 617)
        self.verticalLayout = QtGui.QVBoxLayout(ProgramPageGeneral)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_language = QtGui.QLabel(ProgramPageGeneral)
        self.label_language.setObjectName(_fromUtf8("label_language"))
        self.gridLayout.addWidget(self.label_language, 5, 0, 1, 1)
        self.combo_language = QtGui.QComboBox(ProgramPageGeneral)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.combo_language.sizePolicy().hasHeightForWidth())
        self.combo_language.setSizePolicy(sizePolicy)
        self.combo_language.setObjectName(_fromUtf8("combo_language"))
        self.combo_language.addItem(_fromUtf8(""))
        self.combo_language.addItem(_fromUtf8(""))
        self.combo_language.addItem(_fromUtf8(""))
        self.combo_language.addItem(_fromUtf8(""))
        self.combo_language.addItem(_fromUtf8(""))
        self.combo_language.addItem(_fromUtf8(""))
        self.combo_language.addItem(_fromUtf8(""))
        self.combo_language.addItem(_fromUtf8(""))
        self.combo_language.addItem(_fromUtf8(""))
        self.combo_language.addItem(_fromUtf8(""))
        self.combo_language.addItem(_fromUtf8(""))
        self.combo_language.addItem(_fromUtf8(""))
        self.combo_language.addItem(_fromUtf8(""))
        self.gridLayout.addWidget(self.combo_language, 5, 1, 1, 1)
        self.label_identifier = QtGui.QLabel(ProgramPageGeneral)
        self.label_identifier.setObjectName(_fromUtf8("label_identifier"))
        self.gridLayout.addWidget(self.label_identifier, 3, 0, 1, 1)
        self.edit_identifier = QtGui.QLineEdit(ProgramPageGeneral)
        self.edit_identifier.setMaxLength(256)
        self.edit_identifier.setObjectName(_fromUtf8("edit_identifier"))
        self.gridLayout.addWidget(self.edit_identifier, 3, 1, 1, 1)
        self.label_identifier_help = QtGui.QLabel(ProgramPageGeneral)
        self.label_identifier_help.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_identifier_help.setWordWrap(True)
        self.label_identifier_help.setObjectName(_fromUtf8("label_identifier_help"))
        self.gridLayout.addWidget(self.label_identifier_help, 4, 1, 1, 1)
        self.label_language_help = QtGui.QLabel(ProgramPageGeneral)
        self.label_language_help.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_language_help.setWordWrap(True)
        self.label_language_help.setObjectName(_fromUtf8("label_language_help"))
        self.gridLayout.addWidget(self.label_language_help, 6, 1, 1, 1)
        self.label_name = QtGui.QLabel(ProgramPageGeneral)
        self.label_name.setObjectName(_fromUtf8("label_name"))
        self.gridLayout.addWidget(self.label_name, 0, 0, 1, 1)
        self.edit_name = QtGui.QLineEdit(ProgramPageGeneral)
        self.edit_name.setMaxLength(256)
        self.edit_name.setObjectName(_fromUtf8("edit_name"))
        self.gridLayout.addWidget(self.edit_name, 0, 1, 1, 1)
        self.check_auto_generate = QtGui.QCheckBox(ProgramPageGeneral)
        self.check_auto_generate.setChecked(True)
        self.check_auto_generate.setObjectName(_fromUtf8("check_auto_generate"))
        self.gridLayout.addWidget(self.check_auto_generate, 2, 1, 1, 1)
        self.label_6 = QtGui.QLabel(ProgramPageGeneral)
        self.label_6.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_6.setWordWrap(True)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.gridLayout.addWidget(self.label_6, 1, 1, 1, 1)
        self.text_description = QtGui.QPlainTextEdit(ProgramPageGeneral)
        self.text_description.setObjectName(_fromUtf8("text_description"))
        self.gridLayout.addWidget(self.text_description, 8, 1, 1, 1)
        self.label_description = QtGui.QLabel(ProgramPageGeneral)
        self.label_description.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_description.setObjectName(_fromUtf8("label_description"))
        self.gridLayout.addWidget(self.label_description, 8, 0, 1, 1)
        self.label_octave = QtGui.QLabel(ProgramPageGeneral)
        self.label_octave.setStyleSheet(_fromUtf8("QLabel { color : red }"))
        self.label_octave.setWordWrap(True)
        self.label_octave.setObjectName(_fromUtf8("label_octave"))
        self.gridLayout.addWidget(self.label_octave, 7, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.label_language.setBuddy(self.combo_language)
        self.label_identifier.setBuddy(self.edit_identifier)
        self.label_name.setBuddy(self.edit_name)
        self.label_description.setBuddy(self.text_description)

        self.retranslateUi(ProgramPageGeneral)
        QtCore.QMetaObject.connectSlotsByName(ProgramPageGeneral)
        ProgramPageGeneral.setTabOrder(self.edit_name, self.check_auto_generate)
        ProgramPageGeneral.setTabOrder(self.check_auto_generate, self.edit_identifier)
        ProgramPageGeneral.setTabOrder(self.edit_identifier, self.combo_language)
        ProgramPageGeneral.setTabOrder(self.combo_language, self.text_description)

    def retranslateUi(self, ProgramPageGeneral):
        ProgramPageGeneral.setWindowTitle(_translate("ProgramPageGeneral", "Form", None))
        self.label_language.setText(_translate("ProgramPageGeneral", "Language:", None))
        self.combo_language.setItemText(0, _translate("ProgramPageGeneral", "Select...", None))
        self.combo_language.setItemText(1, _translate("ProgramPageGeneral", "C/C++", None))
        self.combo_language.setItemText(2, _translate("ProgramPageGeneral", "C#", None))
        self.combo_language.setItemText(3, _translate("ProgramPageGeneral", "Delphi/Lazarus", None))
        self.combo_language.setItemText(4, _translate("ProgramPageGeneral", "Java", None))
        self.combo_language.setItemText(5, _translate("ProgramPageGeneral", "JavaScript (Browser/Node.js)", None))
        self.combo_language.setItemText(6, _translate("ProgramPageGeneral", "Octave", None))
        self.combo_language.setItemText(7, _translate("ProgramPageGeneral", "Perl", None))
        self.combo_language.setItemText(8, _translate("ProgramPageGeneral", "PHP", None))
        self.combo_language.setItemText(9, _translate("ProgramPageGeneral", "Python", None))
        self.combo_language.setItemText(10, _translate("ProgramPageGeneral", "Ruby", None))
        self.combo_language.setItemText(11, _translate("ProgramPageGeneral", "Shell", None))
        self.combo_language.setItemText(12, _translate("ProgramPageGeneral", "Visual Basic .NET", None))
        self.label_identifier.setText(_translate("ProgramPageGeneral", "Identifier:", None))
        self.label_identifier_help.setText(_translate("ProgramPageGeneral", "The identifier is used to uniquely identify a program. Therefore, the same identifier cannot be used for more than one program at the same time. If the specified identifier is already in use, it will be shown in red. Because the identifier will also be used as directory name it can only contain letters [a-zA-Z], numbers [0-9], underscores [_], dots [.] and hyphens [-]. But it cannot begin with a dot or a hyphen and has to be at least three characters long.", None))
        self.label_language_help.setText(_translate("ProgramPageGeneral", "The programming language affects how the program will be executed.", None))
        self.label_name.setText(_translate("ProgramPageGeneral", "Name:", None))
        self.check_auto_generate.setText(_translate("ProgramPageGeneral", "Auto-Generate Unique Identifier", None))
        self.label_6.setText(_translate("ProgramPageGeneral", "This is the display name that will be used to refer to the program.", None))
        self.label_description.setText(_translate("ProgramPageGeneral", "Description:", None))
        self.label_octave.setText(_translate("ProgramPageGeneral", "Unfortunately, this image version comes with an Octave version that does not have fully working Java support. Therefore, the Java based Tinkerforge Octave bindings do not support callbacks with this image version. If your Octave program does not use callbacks then you can ignore this warning.", None))

