# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_program.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabProgram(object):
    def setupUi(self, REDTabProgram):
        REDTabProgram.setObjectName(_fromUtf8("REDTabProgram"))
        REDTabProgram.resize(831, 566)
        self.verticalLayout = QtGui.QVBoxLayout(REDTabProgram)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.splitter = QtGui.QSplitter(REDTabProgram)
        self.splitter.setOrientation(QtCore.Qt.Horizontal)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setObjectName(_fromUtf8("splitter"))
        self.layoutWidget = QtGui.QWidget(self.splitter)
        self.layoutWidget.setObjectName(_fromUtf8("layoutWidget"))
        self.gridLayout = QtGui.QGridLayout(self.layoutWidget)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.button_new = QtGui.QPushButton(self.layoutWidget)
        self.button_new.setObjectName(_fromUtf8("button_new"))
        self.gridLayout.addWidget(self.button_new, 3, 0, 1, 1)
        self.button_delete = QtGui.QPushButton(self.layoutWidget)
        self.button_delete.setObjectName(_fromUtf8("button_delete"))
        self.gridLayout.addWidget(self.button_delete, 4, 0, 1, 1)
        self.button_refresh = QtGui.QPushButton(self.layoutWidget)
        self.button_refresh.setObjectName(_fromUtf8("button_refresh"))
        self.gridLayout.addWidget(self.button_refresh, 2, 0, 1, 1)
        self.progress_refresh = QtGui.QProgressBar(self.layoutWidget)
        self.progress_refresh.setMaximum(0)
        self.progress_refresh.setProperty("value", -1)
        self.progress_refresh.setTextVisible(False)
        self.progress_refresh.setObjectName(_fromUtf8("progress_refresh"))
        self.gridLayout.addWidget(self.progress_refresh, 1, 0, 1, 1)
        self.tree_programs = QtGui.QTreeWidget(self.layoutWidget)
        self.tree_programs.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.tree_programs.setRootIsDecorated(False)
        self.tree_programs.setUniformRowHeights(True)
        self.tree_programs.setObjectName(_fromUtf8("tree_programs"))
        self.gridLayout.addWidget(self.tree_programs, 0, 0, 1, 1)
        self.stacked_container = QtGui.QStackedWidget(self.splitter)
        self.stacked_container.setObjectName(_fromUtf8("stacked_container"))
        self.widget_help = QtGui.QWidget()
        self.widget_help.setObjectName(_fromUtf8("widget_help"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.widget_help)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.label = QtGui.QLabel(self.widget_help)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setWordWrap(True)
        self.label.setObjectName(_fromUtf8("label"))
        self.verticalLayout_2.addWidget(self.label)
        self.stacked_container.addWidget(self.widget_help)
        self.verticalLayout.addWidget(self.splitter)

        self.retranslateUi(REDTabProgram)
        QtCore.QMetaObject.connectSlotsByName(REDTabProgram)
        REDTabProgram.setTabOrder(self.tree_programs, self.button_refresh)
        REDTabProgram.setTabOrder(self.button_refresh, self.button_new)
        REDTabProgram.setTabOrder(self.button_new, self.button_delete)

    def retranslateUi(self, REDTabProgram):
        REDTabProgram.setWindowTitle(_translate("REDTabProgram", "REDTabProgram", None))
        self.button_new.setText(_translate("REDTabProgram", "New", None))
        self.button_delete.setText(_translate("REDTabProgram", "Delete", None))
        self.button_refresh.setText(_translate("REDTabProgram", "Refresh", None))
        self.tree_programs.headerItem().setText(0, _translate("REDTabProgram", "Name", None))
        self.tree_programs.headerItem().setText(1, _translate("REDTabProgram", "Status", None))
        self.label.setText(_translate("REDTabProgram", "Click the \"New\" button to create a new program.", None))

