# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_settings_openhab.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabSettingsOpenHAB(object):
    def setupUi(self, REDTabSettingsOpenHAB):
        REDTabSettingsOpenHAB.setObjectName(_fromUtf8("REDTabSettingsOpenHAB"))
        REDTabSettingsOpenHAB.resize(495, 634)
        self.verticalLayout_2 = QtGui.QVBoxLayout(REDTabSettingsOpenHAB)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.label_unsupported = QtGui.QLabel(REDTabSettingsOpenHAB)
        self.label_unsupported.setAlignment(QtCore.Qt.AlignCenter)
        self.label_unsupported.setWordWrap(True)
        self.label_unsupported.setObjectName(_fromUtf8("label_unsupported"))
        self.verticalLayout_2.addWidget(self.label_unsupported)
        self.label_disabled = QtGui.QLabel(REDTabSettingsOpenHAB)
        self.label_disabled.setAlignment(QtCore.Qt.AlignCenter)
        self.label_disabled.setWordWrap(True)
        self.label_disabled.setObjectName(_fromUtf8("label_disabled"))
        self.verticalLayout_2.addWidget(self.label_disabled)
        self.widget_controls = QtGui.QWidget(REDTabSettingsOpenHAB)
        self.widget_controls.setObjectName(_fromUtf8("widget_controls"))
        self.verticalLayout = QtGui.QVBoxLayout(self.widget_controls)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.combo_config = QtGui.QComboBox(self.widget_controls)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.combo_config.sizePolicy().hasHeightForWidth())
        self.combo_config.setSizePolicy(sizePolicy)
        self.combo_config.setObjectName(_fromUtf8("combo_config"))
        self.horizontalLayout.addWidget(self.combo_config)
        self.button_refresh = QtGui.QPushButton(self.widget_controls)
        self.button_refresh.setObjectName(_fromUtf8("button_refresh"))
        self.horizontalLayout.addWidget(self.button_refresh)
        self.button_new = QtGui.QPushButton(self.widget_controls)
        self.button_new.setObjectName(_fromUtf8("button_new"))
        self.horizontalLayout.addWidget(self.button_new)
        self.button_delete = QtGui.QPushButton(self.widget_controls)
        self.button_delete.setObjectName(_fromUtf8("button_delete"))
        self.horizontalLayout.addWidget(self.button_delete)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.label_progress = QtGui.QLabel(self.widget_controls)
        self.label_progress.setObjectName(_fromUtf8("label_progress"))
        self.verticalLayout.addWidget(self.label_progress)
        self.progress = QtGui.QProgressBar(self.widget_controls)
        self.progress.setMaximum(0)
        self.progress.setTextVisible(False)
        self.progress.setObjectName(_fromUtf8("progress"))
        self.verticalLayout.addWidget(self.progress)
        self.splitter = QtGui.QSplitter(self.widget_controls)
        self.splitter.setOrientation(QtCore.Qt.Vertical)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setObjectName(_fromUtf8("splitter"))
        self.edit_errors = QtGui.QPlainTextEdit(self.splitter)
        self.edit_errors.setMinimumSize(QtCore.QSize(0, 100))
        self.edit_errors.setUndoRedoEnabled(False)
        self.edit_errors.setLineWrapMode(QtGui.QPlainTextEdit.NoWrap)
        self.edit_errors.setReadOnly(True)
        self.edit_errors.setObjectName(_fromUtf8("edit_errors"))
        self.stacked_container = QtGui.QStackedWidget(self.splitter)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(self.stacked_container.sizePolicy().hasHeightForWidth())
        self.stacked_container.setSizePolicy(sizePolicy)
        self.stacked_container.setObjectName(_fromUtf8("stacked_container"))
        self.page = QtGui.QWidget()
        self.page.setObjectName(_fromUtf8("page"))
        self.stacked_container.addWidget(self.page)
        self.page_2 = QtGui.QWidget()
        self.page_2.setObjectName(_fromUtf8("page_2"))
        self.stacked_container.addWidget(self.page_2)
        self.verticalLayout.addWidget(self.splitter)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.button_discard = QtGui.QPushButton(self.widget_controls)
        self.button_discard.setObjectName(_fromUtf8("button_discard"))
        self.horizontalLayout_2.addWidget(self.button_discard)
        self.button_apply = QtGui.QPushButton(self.widget_controls)
        self.button_apply.setObjectName(_fromUtf8("button_apply"))
        self.horizontalLayout_2.addWidget(self.button_apply)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.verticalLayout_2.addWidget(self.widget_controls)

        self.retranslateUi(REDTabSettingsOpenHAB)
        QtCore.QMetaObject.connectSlotsByName(REDTabSettingsOpenHAB)

    def retranslateUi(self, REDTabSettingsOpenHAB):
        REDTabSettingsOpenHAB.setWindowTitle(_translate("REDTabSettingsOpenHAB", "Form", None))
        self.label_unsupported.setText(_translate("REDTabSettingsOpenHAB", "openHAB service requires image version >= 1.6", None))
        self.label_disabled.setText(_translate("REDTabSettingsOpenHAB", "openHAB service is disabled.", None))
        self.button_refresh.setText(_translate("REDTabSettingsOpenHAB", "Refresh", None))
        self.button_new.setText(_translate("REDTabSettingsOpenHAB", "New", None))
        self.button_delete.setText(_translate("REDTabSettingsOpenHAB", "Delete", None))
        self.label_progress.setText(_translate("REDTabSettingsOpenHAB", "<progress>", None))
        self.button_discard.setText(_translate("REDTabSettingsOpenHAB", "Discard Changes", None))
        self.button_apply.setText(_translate("REDTabSettingsOpenHAB", "Apply Changes", None))

