# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_update_tinkerforge_software.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDUpdateTinkerforgeSoftware(object):
    def setupUi(self, REDUpdateTinkerforgeSoftware):
        REDUpdateTinkerforgeSoftware.setObjectName(_fromUtf8("REDUpdateTinkerforgeSoftware"))
        REDUpdateTinkerforgeSoftware.setWindowModality(QtCore.Qt.NonModal)
        REDUpdateTinkerforgeSoftware.resize(470, 439)
        REDUpdateTinkerforgeSoftware.setModal(True)
        self.verticalLayout = QtGui.QVBoxLayout(REDUpdateTinkerforgeSoftware)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_pbar = QtGui.QLabel(REDUpdateTinkerforgeSoftware)
        self.label_pbar.setText(_fromUtf8(""))
        self.label_pbar.setAlignment(QtCore.Qt.AlignCenter)
        self.label_pbar.setObjectName(_fromUtf8("label_pbar"))
        self.gridLayout.addWidget(self.label_pbar, 1, 0, 1, 2)
        self.line = QtGui.QFrame(REDUpdateTinkerforgeSoftware)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout.addWidget(self.line, 3, 0, 1, 2)
        self.pbutton_n = QtGui.QPushButton(REDUpdateTinkerforgeSoftware)
        self.pbutton_n.setObjectName(_fromUtf8("pbutton_n"))
        self.gridLayout.addWidget(self.pbutton_n, 4, 0, 1, 1)
        self.tedit_main = QtGui.QTextEdit(REDUpdateTinkerforgeSoftware)
        self.tedit_main.setEnabled(True)
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Roboto [GOOG]"))
        font.setBold(False)
        font.setWeight(50)
        self.tedit_main.setFont(font)
        self.tedit_main.setReadOnly(True)
        self.tedit_main.setObjectName(_fromUtf8("tedit_main"))
        self.gridLayout.addWidget(self.tedit_main, 0, 0, 1, 2)
        self.pbutton_p = QtGui.QPushButton(REDUpdateTinkerforgeSoftware)
        self.pbutton_p.setObjectName(_fromUtf8("pbutton_p"))
        self.gridLayout.addWidget(self.pbutton_p, 4, 1, 1, 1)
        self.pbar = QtGui.QProgressBar(REDUpdateTinkerforgeSoftware)
        self.pbar.setMaximum(0)
        self.pbar.setProperty("value", -1)
        self.pbar.setAlignment(QtCore.Qt.AlignCenter)
        self.pbar.setObjectName(_fromUtf8("pbar"))
        self.gridLayout.addWidget(self.pbar, 2, 0, 1, 2)
        self.verticalLayout.addLayout(self.gridLayout)

        self.retranslateUi(REDUpdateTinkerforgeSoftware)
        QtCore.QMetaObject.connectSlotsByName(REDUpdateTinkerforgeSoftware)

    def retranslateUi(self, REDUpdateTinkerforgeSoftware):
        REDUpdateTinkerforgeSoftware.setWindowTitle(_translate("REDUpdateTinkerforgeSoftware", "Update Tinkerforge Software", None))
        self.pbutton_n.setText(_translate("REDUpdateTinkerforgeSoftware", "Cancel", None))
        self.tedit_main.setHtml(_translate("REDUpdateTinkerforgeSoftware", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'Roboto [GOOG]\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Roboto\';\">With this utility you can check and update all the Tinkerforge bindings and Tinkerforge Brick Viewer installed in your RED Brick.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'Roboto\';\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Roboto\';\">To check whether you need updates click the </span><span style=\" font-family:\'Roboto\'; font-weight:600;\">&quot;Check for Updates&quot;</span><span style=\" font-family:\'Roboto\';\"> button below.</span></p></body></html>", None))
        self.pbutton_p.setText(_translate("REDUpdateTinkerforgeSoftware", "Check for Updates", None))

