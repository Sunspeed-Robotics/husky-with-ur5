# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_settings_services.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabSettingsServices(object):
    def setupUi(self, REDTabSettingsServices):
        REDTabSettingsServices.setObjectName(_fromUtf8("REDTabSettingsServices"))
        REDTabSettingsServices.resize(601, 481)
        self.verticalLayout_2 = QtGui.QVBoxLayout(REDTabSettingsServices)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.scrollArea = QtGui.QScrollArea(REDTabSettingsServices)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName(_fromUtf8("scrollArea"))
        self.scrollAreaWidgetContents = QtGui.QWidget()
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 587, 467))
        self.scrollAreaWidgetContents.setObjectName(_fromUtf8("scrollAreaWidgetContents"))
        self.verticalLayout = QtGui.QVBoxLayout(self.scrollAreaWidgetContents)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.chkbox_webserver = QtGui.QCheckBox(self.scrollAreaWidgetContents)
        self.chkbox_webserver.setObjectName(_fromUtf8("chkbox_webserver"))
        self.gridLayout.addWidget(self.chkbox_webserver, 4, 0, 1, 1)
        self.chkbox_server_monitoring = QtGui.QCheckBox(self.scrollAreaWidgetContents)
        self.chkbox_server_monitoring.setObjectName(_fromUtf8("chkbox_server_monitoring"))
        self.gridLayout.addWidget(self.chkbox_server_monitoring, 7, 0, 1, 1)
        self.chkbox_ap = QtGui.QCheckBox(self.scrollAreaWidgetContents)
        self.chkbox_ap.setObjectName(_fromUtf8("chkbox_ap"))
        self.gridLayout.addWidget(self.chkbox_ap, 6, 0, 1, 1)
        self.chkbox_openhab = QtGui.QCheckBox(self.scrollAreaWidgetContents)
        self.chkbox_openhab.setObjectName(_fromUtf8("chkbox_openhab"))
        self.gridLayout.addWidget(self.chkbox_openhab, 8, 0, 1, 1)
        self.chkbox_splashscreen = QtGui.QCheckBox(self.scrollAreaWidgetContents)
        self.chkbox_splashscreen.setObjectName(_fromUtf8("chkbox_splashscreen"))
        self.gridLayout.addWidget(self.chkbox_splashscreen, 5, 0, 1, 1)
        self.pbutton_services_save = QtGui.QPushButton(self.scrollAreaWidgetContents)
        self.pbutton_services_save.setEnabled(False)
        self.pbutton_services_save.setObjectName(_fromUtf8("pbutton_services_save"))
        self.gridLayout.addWidget(self.pbutton_services_save, 11, 0, 1, 1)
        self.line = QtGui.QFrame(self.scrollAreaWidgetContents)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout.addWidget(self.line, 10, 0, 1, 1)
        self.label_info = QtGui.QLabel(self.scrollAreaWidgetContents)
        self.label_info.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_info.setWordWrap(True)
        self.label_info.setObjectName(_fromUtf8("label_info"))
        self.gridLayout.addWidget(self.label_info, 0, 0, 1, 1)
        self.line_2 = QtGui.QFrame(self.scrollAreaWidgetContents)
        self.line_2.setFrameShape(QtGui.QFrame.HLine)
        self.line_2.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_2.setObjectName(_fromUtf8("line_2"))
        self.gridLayout.addWidget(self.line_2, 1, 0, 1, 1)
        self.chkbox_gpu = QtGui.QCheckBox(self.scrollAreaWidgetContents)
        self.chkbox_gpu.setObjectName(_fromUtf8("chkbox_gpu"))
        self.gridLayout.addWidget(self.chkbox_gpu, 2, 0, 1, 1)
        self.chkbox_desktopenv = QtGui.QCheckBox(self.scrollAreaWidgetContents)
        self.chkbox_desktopenv.setObjectName(_fromUtf8("chkbox_desktopenv"))
        self.gridLayout.addWidget(self.chkbox_desktopenv, 3, 0, 1, 1)
        self.chkbox_mobile_internet = QtGui.QCheckBox(self.scrollAreaWidgetContents)
        self.chkbox_mobile_internet.setObjectName(_fromUtf8("chkbox_mobile_internet"))
        self.gridLayout.addWidget(self.chkbox_mobile_internet, 9, 0, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout_2.addWidget(self.scrollArea)

        self.retranslateUi(REDTabSettingsServices)
        QtCore.QMetaObject.connectSlotsByName(REDTabSettingsServices)
        REDTabSettingsServices.setTabOrder(self.scrollArea, self.chkbox_gpu)
        REDTabSettingsServices.setTabOrder(self.chkbox_gpu, self.chkbox_desktopenv)
        REDTabSettingsServices.setTabOrder(self.chkbox_desktopenv, self.chkbox_webserver)
        REDTabSettingsServices.setTabOrder(self.chkbox_webserver, self.chkbox_splashscreen)
        REDTabSettingsServices.setTabOrder(self.chkbox_splashscreen, self.chkbox_ap)
        REDTabSettingsServices.setTabOrder(self.chkbox_ap, self.pbutton_services_save)

    def retranslateUi(self, REDTabSettingsServices):
        REDTabSettingsServices.setWindowTitle(_translate("REDTabSettingsServices", "Form", None))
        self.chkbox_webserver.setText(_translate("REDTabSettingsServices", "Web Server", None))
        self.chkbox_server_monitoring.setText(_translate("REDTabSettingsServices", "Server Monitoring (enables Web Server and Nagios)", None))
        self.chkbox_ap.setText(_translate("REDTabSettingsServices", "Access Point", None))
        self.chkbox_openhab.setText(_translate("REDTabSettingsServices", "openHAB", None))
        self.chkbox_splashscreen.setText(_translate("REDTabSettingsServices", "Splash Screen", None))
        self.pbutton_services_save.setText(_translate("REDTabSettingsServices", "Save and Reboot", None))
        self.label_info.setText(_translate("REDTabSettingsServices", "Disabling services can make the system boot faster.", None))
        self.chkbox_gpu.setText(_translate("REDTabSettingsServices", "GPU", None))
        self.chkbox_desktopenv.setText(_translate("REDTabSettingsServices", "Desktop Environment", None))
        self.chkbox_mobile_internet.setText(_translate("REDTabSettingsServices", "Mobile Internet", None))

