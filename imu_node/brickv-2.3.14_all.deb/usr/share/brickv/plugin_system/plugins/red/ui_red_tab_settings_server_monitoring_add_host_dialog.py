# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/red_tab_settings_server_monitoring_add_host_dialog.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_REDTabSettingsServerMonitoringAddHostDialog(object):
    def setupUi(self, REDTabSettingsServerMonitoringAddHostDialog):
        REDTabSettingsServerMonitoringAddHostDialog.setObjectName(_fromUtf8("REDTabSettingsServerMonitoringAddHostDialog"))
        REDTabSettingsServerMonitoringAddHostDialog.resize(446, 153)
        self.gridLayout = QtGui.QGridLayout(REDTabSettingsServerMonitoringAddHostDialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.pbutton_sm_add_host_add = QtGui.QPushButton(REDTabSettingsServerMonitoringAddHostDialog)
        self.pbutton_sm_add_host_add.setObjectName(_fromUtf8("pbutton_sm_add_host_add"))
        self.horizontalLayout.addWidget(self.pbutton_sm_add_host_add)
        self.pbutton_sm_add_host_cancel = QtGui.QPushButton(REDTabSettingsServerMonitoringAddHostDialog)
        self.pbutton_sm_add_host_cancel.setObjectName(_fromUtf8("pbutton_sm_add_host_cancel"))
        self.horizontalLayout.addWidget(self.pbutton_sm_add_host_cancel)
        self.gridLayout.addLayout(self.horizontalLayout, 4, 0, 1, 2)
        self.label = QtGui.QLabel(REDTabSettingsServerMonitoringAddHostDialog)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.ledit_sm_add_host_host = QtGui.QLineEdit(REDTabSettingsServerMonitoringAddHostDialog)
        self.ledit_sm_add_host_host.setObjectName(_fromUtf8("ledit_sm_add_host_host"))
        self.gridLayout.addWidget(self.ledit_sm_add_host_host, 0, 1, 1, 1)
        self.label_2 = QtGui.QLabel(REDTabSettingsServerMonitoringAddHostDialog)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.sbox_sm_add_host_port = QtGui.QSpinBox(REDTabSettingsServerMonitoringAddHostDialog)
        self.sbox_sm_add_host_port.setMinimum(1)
        self.sbox_sm_add_host_port.setMaximum(65535)
        self.sbox_sm_add_host_port.setProperty("value", 4223)
        self.sbox_sm_add_host_port.setObjectName(_fromUtf8("sbox_sm_add_host_port"))
        self.gridLayout.addWidget(self.sbox_sm_add_host_port, 1, 1, 1, 1)
        self.chkbox_sm_add_host_authentication = QtGui.QCheckBox(REDTabSettingsServerMonitoringAddHostDialog)
        self.chkbox_sm_add_host_authentication.setText(_fromUtf8(""))
        self.chkbox_sm_add_host_authentication.setObjectName(_fromUtf8("chkbox_sm_add_host_authentication"))
        self.gridLayout.addWidget(self.chkbox_sm_add_host_authentication, 2, 1, 1, 1)
        self.label_3 = QtGui.QLabel(REDTabSettingsServerMonitoringAddHostDialog)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 2, 0, 1, 1)
        self.label_sm_add_host_secret = QtGui.QLabel(REDTabSettingsServerMonitoringAddHostDialog)
        self.label_sm_add_host_secret.setObjectName(_fromUtf8("label_sm_add_host_secret"))
        self.gridLayout.addWidget(self.label_sm_add_host_secret, 3, 0, 1, 1)
        self.ledit_sm_add_host_secret = QtGui.QLineEdit(REDTabSettingsServerMonitoringAddHostDialog)
        self.ledit_sm_add_host_secret.setObjectName(_fromUtf8("ledit_sm_add_host_secret"))
        self.gridLayout.addWidget(self.ledit_sm_add_host_secret, 3, 1, 1, 1)
        spacerItem1 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem1, 5, 0, 1, 2)

        self.retranslateUi(REDTabSettingsServerMonitoringAddHostDialog)
        QtCore.QMetaObject.connectSlotsByName(REDTabSettingsServerMonitoringAddHostDialog)

    def retranslateUi(self, REDTabSettingsServerMonitoringAddHostDialog):
        REDTabSettingsServerMonitoringAddHostDialog.setWindowTitle(_translate("REDTabSettingsServerMonitoringAddHostDialog", "Add Host", None))
        self.pbutton_sm_add_host_add.setText(_translate("REDTabSettingsServerMonitoringAddHostDialog", "Add", None))
        self.pbutton_sm_add_host_cancel.setText(_translate("REDTabSettingsServerMonitoringAddHostDialog", "Cancel", None))
        self.label.setText(_translate("REDTabSettingsServerMonitoringAddHostDialog", "Host:", None))
        self.label_2.setText(_translate("REDTabSettingsServerMonitoringAddHostDialog", "Port:", None))
        self.label_3.setText(_translate("REDTabSettingsServerMonitoringAddHostDialog", "Authentication:", None))
        self.label_sm_add_host_secret.setText(_translate("REDTabSettingsServerMonitoringAddHostDialog", "Secret:", None))

