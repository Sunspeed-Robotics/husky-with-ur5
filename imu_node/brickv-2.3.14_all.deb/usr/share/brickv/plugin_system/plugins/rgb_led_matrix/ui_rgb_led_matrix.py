# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/rgb_led_matrix.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_RGBLEDMatrix(object):
    def setupUi(self, RGBLEDMatrix):
        RGBLEDMatrix.setObjectName(_fromUtf8("RGBLEDMatrix"))
        RGBLEDMatrix.resize(529, 208)
        self.verticalLayout_6 = QtGui.QVBoxLayout(RGBLEDMatrix)
        self.verticalLayout_6.setObjectName(_fromUtf8("verticalLayout_6"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.label_5 = QtGui.QLabel(RGBLEDMatrix)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.horizontalLayout.addWidget(self.label_5)
        self.box_frame_duration = QtGui.QSpinBox(RGBLEDMatrix)
        self.box_frame_duration.setMinimum(10)
        self.box_frame_duration.setMaximum(32768)
        self.box_frame_duration.setProperty("value", 100)
        self.box_frame_duration.setObjectName(_fromUtf8("box_frame_duration"))
        self.horizontalLayout.addWidget(self.box_frame_duration)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.verticalLayout_6.addLayout(self.horizontalLayout)
        self.line = QtGui.QFrame(RGBLEDMatrix)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.verticalLayout_6.addWidget(self.line)
        self.scribble_layout = QtGui.QHBoxLayout()
        self.scribble_layout.setObjectName(_fromUtf8("scribble_layout"))
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.scribble_layout.addItem(spacerItem2)
        spacerItem3 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.scribble_layout.addItem(spacerItem3)
        self.verticalLayout_6.addLayout(self.scribble_layout)
        self.below_scribble_layout = QtGui.QHBoxLayout()
        self.below_scribble_layout.setObjectName(_fromUtf8("below_scribble_layout"))
        spacerItem4 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.below_scribble_layout.addItem(spacerItem4)
        self.label = QtGui.QLabel(RGBLEDMatrix)
        self.label.setObjectName(_fromUtf8("label"))
        self.below_scribble_layout.addWidget(self.label)
        self.button_color = QtGui.QPushButton(RGBLEDMatrix)
        self.button_color.setObjectName(_fromUtf8("button_color"))
        self.below_scribble_layout.addWidget(self.button_color)
        self.button_drawing = QtGui.QPushButton(RGBLEDMatrix)
        self.button_drawing.setObjectName(_fromUtf8("button_drawing"))
        self.below_scribble_layout.addWidget(self.button_drawing)
        self.button_clear_drawing = QtGui.QPushButton(RGBLEDMatrix)
        self.button_clear_drawing.setObjectName(_fromUtf8("button_clear_drawing"))
        self.below_scribble_layout.addWidget(self.button_clear_drawing)
        spacerItem5 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.below_scribble_layout.addItem(spacerItem5)
        self.verticalLayout_6.addLayout(self.below_scribble_layout)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        spacerItem6 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem6)
        self.label_6 = QtGui.QLabel(RGBLEDMatrix)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.horizontalLayout_3.addWidget(self.label_6)
        self.box_speed = QtGui.QSpinBox(RGBLEDMatrix)
        self.box_speed.setMaximum(100)
        self.box_speed.setProperty("value", 1)
        self.box_speed.setObjectName(_fromUtf8("box_speed"))
        self.horizontalLayout_3.addWidget(self.box_speed)
        self.button_gradient = QtGui.QPushButton(RGBLEDMatrix)
        self.button_gradient.setObjectName(_fromUtf8("button_gradient"))
        self.horizontalLayout_3.addWidget(self.button_gradient)
        self.button_dot = QtGui.QPushButton(RGBLEDMatrix)
        self.button_dot.setObjectName(_fromUtf8("button_dot"))
        self.horizontalLayout_3.addWidget(self.button_dot)
        spacerItem7 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem7)
        self.verticalLayout_6.addLayout(self.horizontalLayout_3)
        self.line_3 = QtGui.QFrame(RGBLEDMatrix)
        self.line_3.setFrameShape(QtGui.QFrame.HLine)
        self.line_3.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_3.setObjectName(_fromUtf8("line_3"))
        self.verticalLayout_6.addWidget(self.line_3)
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName(_fromUtf8("horizontalLayout_4"))
        spacerItem8 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem8)
        self.label_8 = QtGui.QLabel(RGBLEDMatrix)
        self.label_8.setObjectName(_fromUtf8("label_8"))
        self.horizontalLayout_4.addWidget(self.label_8)
        self.label_voltage = QtGui.QLabel(RGBLEDMatrix)
        self.label_voltage.setObjectName(_fromUtf8("label_voltage"))
        self.horizontalLayout_4.addWidget(self.label_voltage)
        spacerItem9 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem9)
        self.verticalLayout_6.addLayout(self.horizontalLayout_4)
        spacerItem10 = QtGui.QSpacerItem(20, 0, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_6.addItem(spacerItem10)

        self.retranslateUi(RGBLEDMatrix)
        QtCore.QMetaObject.connectSlotsByName(RGBLEDMatrix)

    def retranslateUi(self, RGBLEDMatrix):
        RGBLEDMatrix.setWindowTitle(_translate("RGBLEDMatrix", "Form", None))
        self.label_5.setText(_translate("RGBLEDMatrix", "Frame Duration [ms]:", None))
        self.label.setText(_translate("RGBLEDMatrix", "Color:", None))
        self.button_color.setText(_translate("RGBLEDMatrix", "Show Color", None))
        self.button_drawing.setText(_translate("RGBLEDMatrix", "Show Drawing", None))
        self.button_clear_drawing.setText(_translate("RGBLEDMatrix", "Clear", None))
        self.label_6.setText(_translate("RGBLEDMatrix", "Speed", None))
        self.button_gradient.setText(_translate("RGBLEDMatrix", "Show Moving Color Gradient", None))
        self.button_dot.setText(_translate("RGBLEDMatrix", "Show Moving Color Dot", None))
        self.label_8.setText(_translate("RGBLEDMatrix", "Supply Voltage:", None))
        self.label_voltage.setText(_translate("RGBLEDMatrix", "0", None))

