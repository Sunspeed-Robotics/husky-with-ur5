# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/calibration.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Calibration(object):
    def setupUi(self, Calibration):
        Calibration.setObjectName(_fromUtf8("Calibration"))
        Calibration.resize(454, 523)
        self.verticalLayout_2 = QtGui.QVBoxLayout(Calibration)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.grid = QtGui.QGridLayout()
        self.grid.setObjectName(_fromUtf8("grid"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem, 3, 2, 1, 1)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem1, 5, 2, 1, 1)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem2, 3, 0, 1, 1)
        self.label_8 = QtGui.QLabel(Calibration)
        self.label_8.setObjectName(_fromUtf8("label_8"))
        self.grid.addWidget(self.label_8, 3, 1, 1, 1)
        spacerItem3 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem3, 2, 0, 1, 1)
        spacerItem4 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem4, 5, 0, 1, 1)
        spacerItem5 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem5, 4, 2, 1, 1)
        spacerItem6 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem6, 2, 2, 1, 1)
        self.label_9 = QtGui.QLabel(Calibration)
        self.label_9.setObjectName(_fromUtf8("label_9"))
        self.grid.addWidget(self.label_9, 2, 1, 1, 1)
        self.label_11 = QtGui.QLabel(Calibration)
        self.label_11.setObjectName(_fromUtf8("label_11"))
        self.grid.addWidget(self.label_11, 4, 1, 1, 1)
        self.label_12 = QtGui.QLabel(Calibration)
        self.label_12.setObjectName(_fromUtf8("label_12"))
        self.grid.addWidget(self.label_12, 5, 1, 1, 1)
        spacerItem7 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem7, 4, 0, 1, 1)
        self.save_calibration = QtGui.QPushButton(Calibration)
        self.save_calibration.setEnabled(False)
        self.save_calibration.setObjectName(_fromUtf8("save_calibration"))
        self.grid.addWidget(self.save_calibration, 7, 0, 1, 3)
        self.line = QtGui.QFrame(Calibration)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.grid.addWidget(self.line, 6, 0, 1, 3)
        self.line_2 = QtGui.QFrame(Calibration)
        self.line_2.setFrameShape(QtGui.QFrame.HLine)
        self.line_2.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_2.setObjectName(_fromUtf8("line_2"))
        self.grid.addWidget(self.line_2, 1, 0, 1, 3)
        self.text_browser = QtGui.QTextBrowser(Calibration)
        self.text_browser.setObjectName(_fromUtf8("text_browser"))
        self.grid.addWidget(self.text_browser, 0, 0, 1, 3)
        self.verticalLayout_2.addLayout(self.grid)

        self.retranslateUi(Calibration)
        QtCore.QMetaObject.connectSlotsByName(Calibration)

    def retranslateUi(self, Calibration):
        Calibration.setWindowTitle(_translate("Calibration", "IMU Calibration", None))
        self.label_8.setText(_translate("Calibration", "Magnetometer", None))
        self.label_9.setText(_translate("Calibration", "Accelerometer", None))
        self.label_11.setText(_translate("Calibration", "Gyroscope", None))
        self.label_12.setText(_translate("Calibration", "System", None))
        self.save_calibration.setText(_translate("Calibration", "Save Calibration", None))
        self.text_browser.setHtml(_translate("Calibration", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'Ubuntu\'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p></body></html>", None))

