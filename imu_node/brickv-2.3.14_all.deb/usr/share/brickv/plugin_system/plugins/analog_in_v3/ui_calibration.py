# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/calibration.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Calibration(object):
    def setupUi(self, Calibration):
        Calibration.setObjectName(_fromUtf8("Calibration"))
        Calibration.resize(354, 456)
        self.verticalLayout_2 = QtGui.QVBoxLayout(Calibration)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.grid = QtGui.QGridLayout()
        self.grid.setObjectName(_fromUtf8("grid"))
        self.label_7 = QtGui.QLabel(Calibration)
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.grid.addWidget(self.label_7, 4, 0, 2, 1)
        self.label_15 = QtGui.QLabel(Calibration)
        self.label_15.setWordWrap(True)
        self.label_15.setObjectName(_fromUtf8("label_15"))
        self.grid.addWidget(self.label_15, 14, 0, 1, 3)
        self.button_cal_gain = QtGui.QPushButton(Calibration)
        self.button_cal_gain.setObjectName(_fromUtf8("button_cal_gain"))
        self.grid.addWidget(self.button_cal_gain, 17, 0, 1, 3)
        self.line_3 = QtGui.QFrame(Calibration)
        self.line_3.setFrameShape(QtGui.QFrame.HLine)
        self.line_3.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_3.setObjectName(_fromUtf8("line_3"))
        self.grid.addWidget(self.line_3, 7, 0, 1, 3)
        self.button_cal_remove = QtGui.QPushButton(Calibration)
        self.button_cal_remove.setObjectName(_fromUtf8("button_cal_remove"))
        self.grid.addWidget(self.button_cal_remove, 9, 0, 1, 3)
        self.label_4 = QtGui.QLabel(Calibration)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.grid.addWidget(self.label_4, 2, 0, 2, 1)
        self.label = QtGui.QLabel(Calibration)
        self.label.setObjectName(_fromUtf8("label"))
        self.grid.addWidget(self.label, 0, 0, 2, 1)
        self.label_16 = QtGui.QLabel(Calibration)
        self.label_16.setObjectName(_fromUtf8("label_16"))
        self.grid.addWidget(self.label_16, 15, 0, 2, 1)
        self.label_14 = QtGui.QLabel(Calibration)
        self.label_14.setTextFormat(QtCore.Qt.AutoText)
        self.label_14.setScaledContents(False)
        self.label_14.setWordWrap(True)
        self.label_14.setObjectName(_fromUtf8("label_14"))
        self.grid.addWidget(self.label_14, 11, 0, 1, 3)
        self.button_cal_offset = QtGui.QPushButton(Calibration)
        self.button_cal_offset.setObjectName(_fromUtf8("button_cal_offset"))
        self.grid.addWidget(self.button_cal_offset, 12, 0, 1, 3)
        self.line_2 = QtGui.QFrame(Calibration)
        self.line_2.setFrameShape(QtGui.QFrame.HLine)
        self.line_2.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_2.setObjectName(_fromUtf8("line_2"))
        self.grid.addWidget(self.line_2, 13, 0, 1, 3)
        self.label_8 = QtGui.QLabel(Calibration)
        self.label_8.setWordWrap(True)
        self.label_8.setObjectName(_fromUtf8("label_8"))
        self.grid.addWidget(self.label_8, 8, 0, 1, 3)
        self.line = QtGui.QFrame(Calibration)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.grid.addWidget(self.line, 10, 0, 1, 3)
        self.label_voltage = QtGui.QLabel(Calibration)
        self.label_voltage.setObjectName(_fromUtf8("label_voltage"))
        self.grid.addWidget(self.label_voltage, 0, 1, 1, 2)
        self.label_offset = QtGui.QLabel(Calibration)
        self.label_offset.setObjectName(_fromUtf8("label_offset"))
        self.grid.addWidget(self.label_offset, 2, 1, 1, 2)
        self.label_2 = QtGui.QLabel(Calibration)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.grid.addWidget(self.label_2, 6, 0, 1, 1)
        self.label_divisor = QtGui.QLabel(Calibration)
        self.label_divisor.setObjectName(_fromUtf8("label_divisor"))
        self.grid.addWidget(self.label_divisor, 6, 1, 1, 2)
        self.label_multiplier = QtGui.QLabel(Calibration)
        self.label_multiplier.setObjectName(_fromUtf8("label_multiplier"))
        self.grid.addWidget(self.label_multiplier, 4, 1, 1, 2)
        self.spinbox_voltage = QtGui.QSpinBox(Calibration)
        self.spinbox_voltage.setMaximum(42000)
        self.spinbox_voltage.setObjectName(_fromUtf8("spinbox_voltage"))
        self.grid.addWidget(self.spinbox_voltage, 16, 1, 1, 2)
        self.verticalLayout_2.addLayout(self.grid)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem)

        self.retranslateUi(Calibration)
        QtCore.QMetaObject.connectSlotsByName(Calibration)

    def retranslateUi(self, Calibration):
        Calibration.setWindowTitle(_translate("Calibration", "Analog In 3.0 Calibration", None))
        self.label_7.setText(_translate("Calibration", "Gain Multiplier:", None))
        self.label_15.setText(_translate("Calibration", "Step 3: To calibrate gain apply a known voltage to VIN. Enter the known correct voltage below and press \"Calibrate Gain\".", None))
        self.button_cal_gain.setText(_translate("Calibration", "Calibrate Gain", None))
        self.button_cal_remove.setText(_translate("Calibration", "Remove Old Calibration", None))
        self.label_4.setText(_translate("Calibration", "Offset:", None))
        self.label.setText(_translate("Calibration", "Voltage:", None))
        self.label_16.setText(_translate("Calibration", "Voltage:", None))
        self.label_14.setText(_translate("Calibration", "Step 2: To calibrate offset connect VIN to GND and press \"Calibrate Offset\".", None))
        self.button_cal_offset.setText(_translate("Calibration", "Calibrate Offset", None))
        self.label_8.setText(_translate("Calibration", "Step 1: To recalibrate the Bricklet you have to remove the old calibration and then calibrate the offset first and gain second. For best result use highest oversampling during calibration.", None))
        self.label_voltage.setText(_translate("Calibration", "0", None))
        self.label_offset.setText(_translate("Calibration", "0", None))
        self.label_2.setText(_translate("Calibration", "Gain Divisor:", None))
        self.label_divisor.setText(_translate("Calibration", "0", None))
        self.label_multiplier.setText(_translate("Calibration", "0", None))
        self.spinbox_voltage.setSuffix(_translate("Calibration", "mV", None))

