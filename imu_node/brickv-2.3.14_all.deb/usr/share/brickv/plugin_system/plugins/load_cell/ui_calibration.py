# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/calibration.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Calibration(object):
    def setupUi(self, Calibration):
        Calibration.setObjectName(_fromUtf8("Calibration"))
        Calibration.resize(447, 241)
        self.verticalLayout = QtGui.QVBoxLayout(Calibration)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.spin_weight = QtGui.QSpinBox(Calibration)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.spin_weight.sizePolicy().hasHeightForWidth())
        self.spin_weight.setSizePolicy(sizePolicy)
        self.spin_weight.setMinimum(100)
        self.spin_weight.setMaximum(1000000000)
        self.spin_weight.setSingleStep(100)
        self.spin_weight.setObjectName(_fromUtf8("spin_weight"))
        self.gridLayout.addWidget(self.spin_weight, 4, 2, 1, 1)
        self.button_weight = QtGui.QPushButton(Calibration)
        self.button_weight.setObjectName(_fromUtf8("button_weight"))
        self.gridLayout.addWidget(self.button_weight, 5, 1, 1, 3)
        self.button_zero = QtGui.QPushButton(Calibration)
        self.button_zero.setObjectName(_fromUtf8("button_zero"))
        self.gridLayout.addWidget(self.button_zero, 1, 1, 1, 3)
        self.label_3 = QtGui.QLabel(Calibration)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 4, 3, 1, 1)
        self.label_step1 = QtGui.QLabel(Calibration)
        self.label_step1.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_step1.setObjectName(_fromUtf8("label_step1"))
        self.gridLayout.addWidget(self.label_step1, 0, 0, 1, 1)
        self.label_6 = QtGui.QLabel(Calibration)
        self.label_6.setWordWrap(True)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.gridLayout.addWidget(self.label_6, 0, 1, 1, 3)
        self.label_step2 = QtGui.QLabel(Calibration)
        self.label_step2.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_step2.setObjectName(_fromUtf8("label_step2"))
        self.gridLayout.addWidget(self.label_step2, 3, 0, 1, 1)
        self.label_7 = QtGui.QLabel(Calibration)
        self.label_7.setWordWrap(True)
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.gridLayout.addWidget(self.label_7, 3, 1, 1, 3)
        self.line = QtGui.QFrame(Calibration)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout.addWidget(self.line, 2, 0, 1, 4)
        self.label_status = QtGui.QLabel(Calibration)
        self.label_status.setWordWrap(True)
        self.label_status.setObjectName(_fromUtf8("label_status"))
        self.gridLayout.addWidget(self.label_status, 7, 1, 1, 3)
        self.line_2 = QtGui.QFrame(Calibration)
        self.line_2.setFrameShape(QtGui.QFrame.HLine)
        self.line_2.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_2.setObjectName(_fromUtf8("line_2"))
        self.gridLayout.addWidget(self.line_2, 6, 0, 1, 4)
        self.label_2 = QtGui.QLabel(Calibration)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 4, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        spacerItem = QtGui.QSpacerItem(20, 15, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)

        self.retranslateUi(Calibration)
        QtCore.QMetaObject.connectSlotsByName(Calibration)
        Calibration.setTabOrder(self.button_zero, self.spin_weight)
        Calibration.setTabOrder(self.spin_weight, self.button_weight)

    def retranslateUi(self, Calibration):
        Calibration.setWindowTitle(_translate("Calibration", "Load Cell Calibration", None))
        self.button_weight.setText(_translate("Calibration", "Calibrate Weight", None))
        self.button_zero.setText(_translate("Calibration", "Calibrate Zero", None))
        self.label_3.setText(_translate("Calibration", "gram", None))
        self.label_step1.setText(_translate("Calibration", "Step 1:", None))
        self.label_6.setText(_translate("Calibration", "Empty the scale and click \"Calibrate Zero\".", None))
        self.label_step2.setText(_translate("Calibration", "Step 2:", None))
        self.label_7.setText(_translate("Calibration", "Add a known weight to the scale, enter it as \"Current Weight\" and click \"Calibrate Weight\".", None))
        self.label_status.setText(_translate("Calibration", "<status>", None))
        self.label_2.setText(_translate("Calibration", "Current Weight:", None))

