# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/calibrate_temperature.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_calibrate_temperature(object):
    def setupUi(self, calibrate_temperature):
        calibrate_temperature.setObjectName(_fromUtf8("calibrate_temperature"))
        calibrate_temperature.resize(329, 260)
        self.verticalLayout = QtGui.QVBoxLayout(calibrate_temperature)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.vlayout = QtGui.QVBoxLayout()
        self.vlayout.setObjectName(_fromUtf8("vlayout"))
        self.start_button = QtGui.QPushButton(calibrate_temperature)
        self.start_button.setEnabled(False)
        self.start_button.setFlat(False)
        self.start_button.setObjectName(_fromUtf8("start_button"))
        self.vlayout.addWidget(self.start_button)
        self.text_label = QtGui.QLabel(calibrate_temperature)
        self.text_label.setAlignment(QtCore.Qt.AlignCenter)
        self.text_label.setWordWrap(True)
        self.text_label.setObjectName(_fromUtf8("text_label"))
        self.vlayout.addWidget(self.text_label)
        self.verticalLayout.addLayout(self.vlayout)

        self.retranslateUi(calibrate_temperature)
        QtCore.QMetaObject.connectSlotsByName(calibrate_temperature)

    def retranslateUi(self, calibrate_temperature):
        calibrate_temperature.setWindowTitle(_translate("calibrate_temperature", "Form", None))
        self.start_button.setText(_translate("calibrate_temperature", "Start Calibration", None))
        self.text_label.setText(_translate("calibrate_temperature", "Not implemented yet. Comming soon!", None))

