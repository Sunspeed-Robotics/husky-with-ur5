# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/calibrate_magnetometer.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_calibrate_magnetometer(object):
    def setupUi(self, calibrate_magnetometer):
        calibrate_magnetometer.setObjectName(_fromUtf8("calibrate_magnetometer"))
        calibrate_magnetometer.resize(329, 260)
        self.verticalLayout = QtGui.QVBoxLayout(calibrate_magnetometer)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.vlayout = QtGui.QVBoxLayout()
        self.vlayout.setObjectName(_fromUtf8("vlayout"))
        self.grid_layout = QtGui.QGridLayout()
        self.grid_layout.setObjectName(_fromUtf8("grid_layout"))
        self.label = QtGui.QLabel(calibrate_magnetometer)
        self.label.setObjectName(_fromUtf8("label"))
        self.grid_layout.addWidget(self.label, 0, 0, 1, 1)
        self.label_2 = QtGui.QLabel(calibrate_magnetometer)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.grid_layout.addWidget(self.label_2, 0, 1, 1, 1)
        self.label_3 = QtGui.QLabel(calibrate_magnetometer)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.grid_layout.addWidget(self.label_3, 0, 2, 1, 1)
        self.label_4 = QtGui.QLabel(calibrate_magnetometer)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.grid_layout.addWidget(self.label_4, 0, 3, 1, 1)
        self.label_5 = QtGui.QLabel(calibrate_magnetometer)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.grid_layout.addWidget(self.label_5, 1, 0, 1, 1)
        self.label_6 = QtGui.QLabel(calibrate_magnetometer)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.grid_layout.addWidget(self.label_6, 2, 0, 1, 1)
        self.gain_x = QtGui.QLabel(calibrate_magnetometer)
        self.gain_x.setObjectName(_fromUtf8("gain_x"))
        self.grid_layout.addWidget(self.gain_x, 1, 1, 1, 1)
        self.bias_x = QtGui.QLabel(calibrate_magnetometer)
        self.bias_x.setObjectName(_fromUtf8("bias_x"))
        self.grid_layout.addWidget(self.bias_x, 2, 1, 1, 1)
        self.gain_y = QtGui.QLabel(calibrate_magnetometer)
        self.gain_y.setObjectName(_fromUtf8("gain_y"))
        self.grid_layout.addWidget(self.gain_y, 1, 2, 1, 1)
        self.bias_y = QtGui.QLabel(calibrate_magnetometer)
        self.bias_y.setObjectName(_fromUtf8("bias_y"))
        self.grid_layout.addWidget(self.bias_y, 2, 2, 1, 1)
        self.gain_z = QtGui.QLabel(calibrate_magnetometer)
        self.gain_z.setObjectName(_fromUtf8("gain_z"))
        self.grid_layout.addWidget(self.gain_z, 1, 3, 1, 1)
        self.bias_z = QtGui.QLabel(calibrate_magnetometer)
        self.bias_z.setObjectName(_fromUtf8("bias_z"))
        self.grid_layout.addWidget(self.bias_z, 2, 3, 1, 1)
        self.vlayout.addLayout(self.grid_layout)
        self.start_button = QtGui.QPushButton(calibrate_magnetometer)
        self.start_button.setObjectName(_fromUtf8("start_button"))
        self.vlayout.addWidget(self.start_button)
        self.text_label = QtGui.QLabel(calibrate_magnetometer)
        self.text_label.setWordWrap(True)
        self.text_label.setObjectName(_fromUtf8("text_label"))
        self.vlayout.addWidget(self.text_label)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.vlayout.addItem(spacerItem)
        self.verticalLayout.addLayout(self.vlayout)

        self.retranslateUi(calibrate_magnetometer)
        QtCore.QMetaObject.connectSlotsByName(calibrate_magnetometer)

    def retranslateUi(self, calibrate_magnetometer):
        calibrate_magnetometer.setWindowTitle(_translate("calibrate_magnetometer", "Form", None))
        self.label.setText(_translate("calibrate_magnetometer", "Type", None))
        self.label_2.setText(_translate("calibrate_magnetometer", "X", None))
        self.label_3.setText(_translate("calibrate_magnetometer", "Y", None))
        self.label_4.setText(_translate("calibrate_magnetometer", "Z", None))
        self.label_5.setText(_translate("calibrate_magnetometer", "Gain", None))
        self.label_6.setText(_translate("calibrate_magnetometer", "Bias", None))
        self.gain_x.setText(_translate("calibrate_magnetometer", "?", None))
        self.bias_x.setText(_translate("calibrate_magnetometer", "?", None))
        self.gain_y.setText(_translate("calibrate_magnetometer", "?", None))
        self.bias_y.setText(_translate("calibrate_magnetometer", "?", None))
        self.gain_z.setText(_translate("calibrate_magnetometer", "?", None))
        self.bias_z.setText(_translate("calibrate_magnetometer", "?", None))
        self.start_button.setText(_translate("calibrate_magnetometer", "Start Calibration", None))
        self.text_label.setText(_translate("calibrate_magnetometer", "Text", None))

